package com.artauction.auction.repository;

import com.artauction.auction.entity.Artwork;
import com.artauction.auction.entity.ArtworkStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ArtworkRepository extends JpaRepository<Artwork, String> {
    List<Artwork> findByArtistId(String artistId);
    List<Artwork> findByStatus(ArtworkStatus status);
    List<Artwork> findByTitleContainingIgnoreCase(String title);
}
