package com.artauction.auction.service;

import com.artauction.auction.client.NotificationServiceClient;
import com.artauction.auction.dto.BidDto;
import com.artauction.auction.dto.BidRequest;
import com.artauction.auction.entity.Auction;
import com.artauction.auction.entity.AuctionStatus;
import com.artauction.auction.entity.Bid;
import com.artauction.auction.exception.AuctionNotFoundException;
import com.artauction.auction.repository.AuctionRepository;
import com.artauction.auction.repository.BidRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.lang.NonNull;

@Service
@Transactional
public class BidService {

    @Autowired private BidRepository bidRepository;
    @Autowired private AuctionRepository auctionRepository;
    @Autowired private NotificationServiceClient notificationClient;

    public BidDto placeBid(@NonNull String auctionId,
                           @NonNull BidRequest req,
                           @NonNull String bidderId,
                           @NonNull String bidderName,
                           String bidderEmail) {

        Auction auction = auctionRepository.findById(auctionId)
                .orElseThrow(() -> new AuctionNotFoundException("Auction not found: " + auctionId));

        if (auction.getStatus() != AuctionStatus.ACTIVE)
            throw new RuntimeException("Auction is not active");
        if (LocalDateTime.now().isAfter(auction.getEndTime()))
            throw new RuntimeException("Auction has ended");
        if (auction.getArtistId().equals(bidderId))
            throw new RuntimeException("Artists cannot bid on their own artwork");
        if (req.getAmount().compareTo(auction.getCurrentPrice()) <= 0)
            throw new RuntimeException("Bid must be higher than current price: " + auction.getCurrentPrice());

        Bid bid = new Bid();
        bid.setAuctionId(auctionId);
        bid.setBidderId(bidderId);
        bid.setBidderName(bidderName);
        bid.setBidderEmail(bidderEmail);   // persist so scheduler can email the winner
        bid.setAmount(req.getAmount());
        Bid saved = bidRepository.save(bid);

        auction.setCurrentPrice(req.getAmount());
        auction.setTotalBids(auction.getTotalBids() + 1);
        auctionRepository.save(auction);

        // Notify (includes email) — send to artist's email stored on auction
        try {
            Map<String, String> payload = new HashMap<>();
            payload.put("type",         "NEW_BID");
            payload.put("auctionId",    auctionId);
            payload.put("userId",       auction.getArtistId());      // notify artist
            payload.put("userEmail",    auction.getArtistEmail());   // artist's email (see note below)
            payload.put("userName",     bidderName);
            payload.put("bidderName",   bidderName);
            payload.put("artworkTitle", auction.getArtworkTitle());
            payload.put("amount",       req.getAmount().toString());
            payload.put("message",      "New bid of $" + req.getAmount() + " by " + bidderName
                                        + " on " + auction.getArtworkTitle());
            notificationClient.sendNotification(payload);
        } catch (Exception ignored) {}

        return BidDto.fromEntity(saved);
    }

    @Transactional(readOnly = true)
    public List<BidDto> getBidsByAuction(String auctionId) {
        return bidRepository.findByAuctionIdOrderByAmountDesc(auctionId)
                .stream().map(BidDto::fromEntity).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<BidDto> getBidsByBidder(String bidderId) {
        return bidRepository.findByBidderId(bidderId)
                .stream().map(BidDto::fromEntity).collect(Collectors.toList());
    }
}
