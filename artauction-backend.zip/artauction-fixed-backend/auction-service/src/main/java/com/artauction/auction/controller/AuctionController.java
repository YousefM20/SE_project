package com.artauction.auction.controller;

import com.artauction.auction.dto.AuctionCreateRequest;
import com.artauction.auction.dto.AuctionDto;
import com.artauction.auction.security.JwtTokenProvider;
import com.artauction.auction.service.AuctionService;
import io.jsonwebtoken.Claims;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/auctions")
@CrossOrigin(origins = "*")
public class AuctionController {

    @Autowired private AuctionService auctionService;
    @Autowired private JwtTokenProvider jwtTokenProvider;

    @GetMapping
    public ResponseEntity<List<AuctionDto>> getAllAuctions() {
        return ResponseEntity.ok(auctionService.getAllAuctions());
    }

    @GetMapping("/active")
    public ResponseEntity<List<AuctionDto>> getActiveAuctions() {
        return ResponseEntity.ok(auctionService.getActiveAuctions());
    }

    @GetMapping("/{id}")
    public ResponseEntity<AuctionDto> getAuctionById(@PathVariable String id) {
        return ResponseEntity.ok(auctionService.getAuctionById(id));
    }

    @GetMapping("/artist/{artistId}")
    public ResponseEntity<List<AuctionDto>> getByArtist(@PathVariable String artistId) {
        return ResponseEntity.ok(auctionService.getAuctionsByArtist(artistId));
    }

    @PostMapping
    @PreAuthorize("hasRole('ARTIST')")
    public ResponseEntity<AuctionDto> createAuction(@Valid @RequestBody AuctionCreateRequest req,
            @RequestHeader("Authorization") String authHeader) {
        Claims claims = jwtTokenProvider.extractClaims(authHeader.substring(7));
        String artistId    = claims.get("userId", String.class);
        String artistEmail = claims.getSubject();   // JWT subject = email
        String artistName  = claims.get("fullName", String.class);
        return ResponseEntity.ok(auctionService.createAuction(req, artistId, artistEmail, artistName));
    }

    @PutMapping("/{id}/cancel")
    @PreAuthorize("hasAnyRole('ARTIST','ADMIN','EMPLOYEE')")
    public ResponseEntity<AuctionDto> cancelAuction(@PathVariable String id,
            @RequestHeader("Authorization") String authHeader) {
        Claims claims = jwtTokenProvider.extractClaims(authHeader.substring(7));
        String requesterId  = claims.get("userId", String.class);
        String role         = claims.get("role", String.class);
        boolean staffOverride = "ADMIN".equals(role) || "EMPLOYEE".equals(role);
        return ResponseEntity.ok(auctionService.cancelAuction(id, requesterId, staffOverride));
    }
}
