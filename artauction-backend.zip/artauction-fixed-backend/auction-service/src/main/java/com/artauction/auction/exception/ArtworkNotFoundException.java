package com.artauction.auction.exception;

public class ArtworkNotFoundException extends RuntimeException {
    public ArtworkNotFoundException(String message) { super(message); }
}
