package com.artauction.auction.entity;

public enum ArtworkStatus {
    AVAILABLE,
    IN_AUCTION,
    SOLD,
    WITHDRAWN
}
