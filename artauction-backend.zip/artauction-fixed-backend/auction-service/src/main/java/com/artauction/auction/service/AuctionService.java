package com.artauction.auction.service;

import com.artauction.auction.client.NotificationServiceClient;
import com.artauction.auction.dto.AuctionCreateRequest;
import com.artauction.auction.dto.AuctionDto;
import com.artauction.auction.entity.*;
import com.artauction.auction.exception.AuctionNotFoundException;
import com.artauction.auction.exception.ArtworkNotFoundException;
import com.artauction.auction.repository.ArtworkRepository;
import com.artauction.auction.repository.AuctionRepository;
import com.artauction.auction.repository.BidRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Transactional
@SuppressWarnings("null")
public class AuctionService {

    @Autowired private AuctionRepository auctionRepository;
    @Autowired private ArtworkRepository artworkRepository;
    @Autowired private BidRepository bidRepository;
    @Autowired private NotificationServiceClient notificationClient;

    public AuctionDto createAuction(AuctionCreateRequest req,
                                    String artistId,
                                    String artistEmail,
                                    String artistName) {
        Artwork artwork = artworkRepository.findById(req.getArtworkId())
                .orElseThrow(() -> new ArtworkNotFoundException("Artwork not found: " + req.getArtworkId()));

        if (!artwork.getArtistId().equals(artistId))
            throw new RuntimeException("You can only auction your own artworks");
        if (artwork.getStatus() != ArtworkStatus.AVAILABLE)
            throw new RuntimeException("Artwork is not available for auction");
        if (req.getEndTime().isBefore(req.getStartTime()))
            throw new RuntimeException("End time must be after start time");

        Auction auction = new Auction();
        auction.setArtworkId(artwork.getId());
        auction.setArtworkTitle(artwork.getTitle());
        auction.setArtistId(artistId);
        auction.setArtistEmail(artistEmail);   // store for notification emails
        auction.setArtistName(artistName);
        auction.setStartingPrice(artwork.getStartingPrice());
        auction.setCurrentPrice(artwork.getStartingPrice());
        auction.setReservePrice(req.getReservePrice());
        auction.setStartTime(req.getStartTime());
        auction.setEndTime(req.getEndTime());

        boolean startsNow = !req.getStartTime().isAfter(LocalDateTime.now());
        auction.setStatus(startsNow ? AuctionStatus.ACTIVE : AuctionStatus.SCHEDULED);

        if (startsNow) {
            artwork.setStatus(ArtworkStatus.IN_AUCTION);
            artworkRepository.save(artwork);
        }

        Auction saved = auctionRepository.save(auction);

        // Notify artist by email
        try {
            Map<String, String> payload = new HashMap<>();
            payload.put("type",         "AUCTION_CREATED");
            payload.put("userId",       artistId);
            payload.put("userEmail",    artistEmail);
            payload.put("userName",     artistName);
            payload.put("auctionId",    saved.getId());
            payload.put("artworkTitle", saved.getArtworkTitle());
            payload.put("message",      "Your auction for \"" + saved.getArtworkTitle() + "\" is now live!");
            notificationClient.sendNotification(payload);
        } catch (Exception ignored) {}

        return AuctionDto.fromEntity(saved);
    }

    @Transactional(readOnly = true)
    public List<AuctionDto> getAllAuctions() {
        return auctionRepository.findAll().stream()
                .map(AuctionDto::fromEntity).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<AuctionDto> getActiveAuctions() {
        return auctionRepository.findByStatus(AuctionStatus.ACTIVE).stream()
                .map(AuctionDto::fromEntity).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public AuctionDto getAuctionById(String id) {
        return AuctionDto.fromEntity(findOrThrow(id));
    }

    @Transactional(readOnly = true)
    public List<AuctionDto> getAuctionsByArtist(String artistId) {
        return auctionRepository.findByArtistId(artistId).stream()
                .map(AuctionDto::fromEntity).collect(Collectors.toList());
    }

    public AuctionDto cancelAuction(String auctionId, String requesterId, boolean isAdmin) {
        Auction auction = findOrThrow(auctionId);
        if (!isAdmin && !auction.getArtistId().equals(requesterId))
            throw new RuntimeException("Not authorized to cancel this auction");
        if (auction.getStatus() == AuctionStatus.ENDED)
            throw new RuntimeException("Cannot cancel an ended auction");

        auction.setStatus(AuctionStatus.CANCELLED);
        Artwork artwork = artworkRepository.findById(auction.getArtworkId()).orElse(null);
        if (artwork != null) {
            artwork.setStatus(ArtworkStatus.AVAILABLE);
            artworkRepository.save(artwork);
        }
        return AuctionDto.fromEntity(auctionRepository.save(auction));
    }

    /** Called by scheduler every minute */
    public void activateScheduledAuctions() {
        List<Auction> toActivate = auctionRepository
                .findByStatusAndStartTimeBefore(AuctionStatus.SCHEDULED, LocalDateTime.now());
        for (Auction a : toActivate) {
            a.setStatus(AuctionStatus.ACTIVE);
            auctionRepository.save(a);
            artworkRepository.findById(a.getArtworkId()).ifPresent(art -> {
                art.setStatus(ArtworkStatus.IN_AUCTION);
                artworkRepository.save(art);
            });
        }
    }

    public void closeExpiredAuctions() {
        List<Auction> toClose = auctionRepository
                .findByStatusAndEndTimeBefore(AuctionStatus.ACTIVE, LocalDateTime.now());
        for (Auction a : toClose) {
            a.setStatus(AuctionStatus.ENDED);

            bidRepository.findTopBidByAuctionId(a.getId()).ifPresent(topBid -> {
                a.setWinnerId(topBid.getBidderId());
                a.setWinnerName(topBid.getBidderName());

                artworkRepository.findById(a.getArtworkId()).ifPresent(art -> {
                    art.setStatus(ArtworkStatus.SOLD);
                    artworkRepository.save(art);
                });

                // Notify winner and artist by email
                try {
                    // Winner notification
                    Map<String, String> winnerPayload = new HashMap<>();
                    winnerPayload.put("type",         "AUCTION_ENDED");
                    winnerPayload.put("userId",       topBid.getBidderId());
                    winnerPayload.put("userEmail",    topBid.getBidderEmail());  // see Bid entity below
                    winnerPayload.put("userName",     topBid.getBidderName());
                    winnerPayload.put("auctionId",    a.getId());
                    winnerPayload.put("artworkTitle", a.getArtworkTitle());
                    winnerPayload.put("amount",       topBid.getAmount().toString());
                    winnerPayload.put("winnerName",   topBid.getBidderName());
                    winnerPayload.put("artistEmail",  a.getArtistEmail());
                    winnerPayload.put("artistName",   a.getArtistName());
                    winnerPayload.put("message",      "Auction ended. Winner: " + topBid.getBidderName());
                    notificationClient.sendNotification(winnerPayload);
                } catch (Exception ignored) {}
            });

            // If no bids, restore artwork
            if (a.getWinnerId() == null) {
                artworkRepository.findById(a.getArtworkId()).ifPresent(art -> {
                    art.setStatus(ArtworkStatus.AVAILABLE);
                    artworkRepository.save(art);
                });
            }

            auctionRepository.save(a);
        }
    }

    private Auction findOrThrow(String id) {
        return auctionRepository.findById(id)
                .orElseThrow(() -> new AuctionNotFoundException("Auction not found: " + id));
    }
}
