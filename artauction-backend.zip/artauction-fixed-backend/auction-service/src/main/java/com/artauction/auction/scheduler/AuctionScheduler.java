package com.artauction.auction.scheduler;

import com.artauction.auction.service.AuctionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class AuctionScheduler {

    private static final Logger log = LoggerFactory.getLogger(AuctionScheduler.class);

    @Autowired private AuctionService auctionService;

    // Every 30 seconds: activate scheduled auctions whose start time has passed
    @Scheduled(fixedDelay = 30000)
    public void activateScheduledAuctions() {
        log.info("[SCHEDULER] Checking for auctions to activate...");
        auctionService.activateScheduledAuctions();
    }

    // Every 30 seconds: close auctions whose end time has passed
    @Scheduled(fixedDelay = 30000, initialDelay = 15000)
    public void closeExpiredAuctions() {
        log.info("[SCHEDULER] Checking for auctions to close...");
        auctionService.closeExpiredAuctions();
    }
}
