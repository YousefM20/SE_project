package com.artauction.auction.repository;

import com.artauction.auction.entity.Auction;
import com.artauction.auction.entity.AuctionStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AuctionRepository extends JpaRepository<Auction, String> {
    List<Auction> findByStatus(AuctionStatus status);
    List<Auction> findByArtistId(String artistId);
    List<Auction> findByArtworkId(String artworkId);
    List<Auction> findByStatusAndStartTimeBefore(AuctionStatus status, LocalDateTime time);
    List<Auction> findByStatusAndEndTimeBefore(AuctionStatus status, LocalDateTime time);
}
