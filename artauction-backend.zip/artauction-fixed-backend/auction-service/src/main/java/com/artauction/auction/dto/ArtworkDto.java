package com.artauction.auction.dto;

import com.artauction.auction.entity.Artwork;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class ArtworkDto {
    private String id;
    private String title;
    private String description;
    private String artistId;
    private String artistName;
    private String medium;
    private String dimensions;
    private Integer yearCreated;
    private BigDecimal startingPrice;
    private String imageUrl;
    private String status;
    private LocalDateTime createdAt;

    public static ArtworkDto fromEntity(Artwork a) {
        ArtworkDto d = new ArtworkDto();
        d.id = a.getId(); d.title = a.getTitle(); d.description = a.getDescription();
        d.artistId = a.getArtistId(); d.artistName = a.getArtistName();
        d.medium = a.getMedium(); d.dimensions = a.getDimensions();
        d.yearCreated = a.getYearCreated(); d.startingPrice = a.getStartingPrice();
        d.imageUrl = a.getImageUrl(); d.status = a.getStatus().name();
        d.createdAt = a.getCreatedAt();
        return d;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getArtistId() { return artistId; }
    public String getArtistName() { return artistName; }
    public String getMedium() { return medium; }
    public String getDimensions() { return dimensions; }
    public Integer getYearCreated() { return yearCreated; }
    public BigDecimal getStartingPrice() { return startingPrice; }
    public String getImageUrl() { return imageUrl; }
    public String getStatus() { return status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setId(String id) { this.id = id; }
    public void setTitle(String title) { this.title = title; }
    public void setDescription(String description) { this.description = description; }
    public void setArtistId(String artistId) { this.artistId = artistId; }
    public void setArtistName(String artistName) { this.artistName = artistName; }
    public void setMedium(String medium) { this.medium = medium; }
    public void setDimensions(String dimensions) { this.dimensions = dimensions; }
    public void setYearCreated(Integer yearCreated) { this.yearCreated = yearCreated; }
    public void setStartingPrice(BigDecimal startingPrice) { this.startingPrice = startingPrice; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    public void setStatus(String status) { this.status = status; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
