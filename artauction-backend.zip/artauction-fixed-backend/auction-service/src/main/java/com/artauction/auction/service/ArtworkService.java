package com.artauction.auction.service;

import com.artauction.auction.dto.ArtworkCreateRequest;
import com.artauction.auction.dto.ArtworkDto;
import com.artauction.auction.entity.Artwork;
import com.artauction.auction.entity.ArtworkStatus;
import com.artauction.auction.exception.ArtworkNotFoundException;
import com.artauction.auction.repository.ArtworkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.lang.NonNull;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class ArtworkService {

    @Autowired
    private ArtworkRepository artworkRepository;

    public ArtworkDto createArtwork(ArtworkCreateRequest req, @NonNull String artistId, @NonNull String artistName) {
        Artwork a = new Artwork();
        a.setTitle(req.getTitle());
        a.setDescription(req.getDescription());
        a.setArtistId(artistId);
        a.setArtistName(artistName);
        a.setMedium(req.getMedium());
        a.setDimensions(req.getDimensions());
        a.setYearCreated(req.getYearCreated());
        a.setStartingPrice(req.getStartingPrice());
        a.setImageUrl(req.getImageUrl());
        a.setStatus(ArtworkStatus.AVAILABLE);
        return ArtworkDto.fromEntity(artworkRepository.save(a));
    }

    @Transactional(readOnly = true)
    public List<ArtworkDto> getAllArtworks() {
        return artworkRepository.findAll().stream().map(ArtworkDto::fromEntity).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ArtworkDto getArtworkById(@NonNull String id) {
        return ArtworkDto.fromEntity(findOrThrow(id));
    }

    @Transactional(readOnly = true)
    public List<ArtworkDto> getArtworksByArtist(@NonNull String artistId) {
        return artworkRepository.findByArtistId(artistId).stream().map(ArtworkDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ArtworkDto> searchArtworks(@NonNull String title) {
        return artworkRepository.findByTitleContainingIgnoreCase(title).stream().map(ArtworkDto::fromEntity)
                .collect(Collectors.toList());
    }

    public ArtworkDto updateArtwork(@NonNull String id, ArtworkCreateRequest req, @NonNull String requesterId) {
        Artwork a = findOrThrow(id);
        if (!a.getArtistId().equals(requesterId))
            throw new RuntimeException("Not authorized to update this artwork");
        if (a.getStatus() != ArtworkStatus.AVAILABLE)
            throw new RuntimeException("Cannot update artwork that is in auction or sold");
        a.setTitle(req.getTitle());
        a.setDescription(req.getDescription());
        a.setMedium(req.getMedium());
        a.setDimensions(req.getDimensions());
        a.setYearCreated(req.getYearCreated());
        a.setStartingPrice(req.getStartingPrice());
        a.setImageUrl(req.getImageUrl());
        return ArtworkDto.fromEntity(artworkRepository.save(a));
    }

    public void deleteArtwork(@NonNull String id, @NonNull String requesterId, boolean isAdmin) {
        Artwork a = findOrThrow(id);
        if (!isAdmin && !a.getArtistId().equals(requesterId))
            throw new RuntimeException("Not authorized");
        if (a.getStatus() == ArtworkStatus.IN_AUCTION)
            throw new RuntimeException("Cannot delete artwork currently in auction");
        artworkRepository.deleteById(id);
    }

    private Artwork findOrThrow(@NonNull String id) {
        return artworkRepository.findById(id)
                .orElseThrow(() -> new ArtworkNotFoundException("Artwork not found: " + id));
    }
}
