package com.artauction.auction.controller;

import com.artauction.auction.dto.BidDto;
import com.artauction.auction.dto.BidRequest;
import com.artauction.auction.security.JwtTokenProvider;
import com.artauction.auction.service.BidService;
import io.jsonwebtoken.Claims;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@SuppressWarnings("null")
@RequestMapping("/api/bids")
@CrossOrigin(origins = "*")
public class BidController {

    @Autowired private BidService bidService;
    @Autowired private JwtTokenProvider jwtTokenProvider;

    @GetMapping("/auction/{auctionId}")
    public ResponseEntity<List<BidDto>> getBidsByAuction(@PathVariable String auctionId) {
        return ResponseEntity.ok(bidService.getBidsByAuction(auctionId));
    }

    @GetMapping("/my-bids")
    @PreAuthorize("hasAnyRole('BUYER','ARTIST','ADMIN','EMPLOYEE')")
    public ResponseEntity<List<BidDto>> getMyBids(@RequestHeader("Authorization") String authHeader) {
        Claims claims = jwtTokenProvider.extractClaims(authHeader.substring(7));
        String bidderId = claims.get("userId", String.class);
        return ResponseEntity.ok(bidService.getBidsByBidder(bidderId));
    }

    @PostMapping("/auction/{auctionId}")
    @PreAuthorize("hasRole('BUYER')")
    public ResponseEntity<BidDto> placeBid(@PathVariable String auctionId,
            @Valid @RequestBody BidRequest req,
            @RequestHeader("Authorization") String authHeader) {
        Claims claims = jwtTokenProvider.extractClaims(authHeader.substring(7));
        String bidderId   = claims.get("userId", String.class);
        String bidderName = claims.get("fullName", String.class);
        String bidderEmail = claims.getSubject();   // subject = email (set by user-service JwtTokenProvider)
        return ResponseEntity.ok(bidService.placeBid(auctionId, req, bidderId, bidderName, bidderEmail));
    }
}
