package com.artauction.auction.dto;

import com.artauction.auction.entity.Auction;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class AuctionDto {
    private String id;
    private String artworkId;
    private String artworkTitle;
    private String artistId;
    private BigDecimal startingPrice;
    private BigDecimal currentPrice;
    private BigDecimal reservePrice;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String status;
    private String winnerId;
    private String winnerName;
    private int totalBids;
    private LocalDateTime createdAt;

    public static AuctionDto fromEntity(Auction a) {
        AuctionDto d = new AuctionDto();
        d.id = a.getId(); d.artworkId = a.getArtworkId(); d.artworkTitle = a.getArtworkTitle();
        d.artistId = a.getArtistId(); d.startingPrice = a.getStartingPrice();
        d.currentPrice = a.getCurrentPrice(); d.reservePrice = a.getReservePrice();
        d.startTime = a.getStartTime(); d.endTime = a.getEndTime();
        d.status = a.getStatus().name(); d.winnerId = a.getWinnerId();
        d.winnerName = a.getWinnerName(); d.totalBids = a.getTotalBids();
        d.createdAt = a.getCreatedAt();
        return d;
    }

    public String getId() { return id; }
    public String getArtworkId() { return artworkId; }
    public String getArtworkTitle() { return artworkTitle; }
    public String getArtistId() { return artistId; }
    public BigDecimal getStartingPrice() { return startingPrice; }
    public BigDecimal getCurrentPrice() { return currentPrice; }
    public BigDecimal getReservePrice() { return reservePrice; }
    public LocalDateTime getStartTime() { return startTime; }
    public LocalDateTime getEndTime() { return endTime; }
    public String getStatus() { return status; }
    public String getWinnerId() { return winnerId; }
    public String getWinnerName() { return winnerName; }
    public int getTotalBids() { return totalBids; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setId(String id) { this.id = id; }
    public void setArtworkId(String v) { this.artworkId = v; }
    public void setArtworkTitle(String v) { this.artworkTitle = v; }
    public void setArtistId(String v) { this.artistId = v; }
    public void setStartingPrice(BigDecimal v) { this.startingPrice = v; }
    public void setCurrentPrice(BigDecimal v) { this.currentPrice = v; }
    public void setReservePrice(BigDecimal v) { this.reservePrice = v; }
    public void setStartTime(LocalDateTime v) { this.startTime = v; }
    public void setEndTime(LocalDateTime v) { this.endTime = v; }
    public void setStatus(String v) { this.status = v; }
    public void setWinnerId(String v) { this.winnerId = v; }
    public void setWinnerName(String v) { this.winnerName = v; }
    public void setTotalBids(int v) { this.totalBids = v; }
    public void setCreatedAt(LocalDateTime v) { this.createdAt = v; }
}
