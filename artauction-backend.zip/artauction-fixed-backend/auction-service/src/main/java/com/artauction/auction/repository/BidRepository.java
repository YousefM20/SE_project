package com.artauction.auction.repository;

import com.artauction.auction.entity.Bid;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public interface BidRepository extends JpaRepository<Bid, String> {
    List<Bid> findByAuctionIdOrderByAmountDesc(String auctionId);
    List<Bid> findByBidderId(String bidderId);

    @Query("SELECT MAX(b.amount) FROM Bid b WHERE b.auctionId = :auctionId")
    Optional<BigDecimal> findMaxAmountByAuctionId(String auctionId);

    @Query("SELECT b FROM Bid b WHERE b.auctionId = :auctionId ORDER BY b.amount DESC LIMIT 1")
    Optional<Bid> findTopBidByAuctionId(String auctionId);

    long countByAuctionId(String auctionId);
}
