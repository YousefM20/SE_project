package com.artauction.auction.controller;

import com.artauction.auction.dto.ArtworkCreateRequest;
import com.artauction.auction.dto.ArtworkDto;
import com.artauction.auction.service.ArtworkService;
import io.jsonwebtoken.Claims;
import com.artauction.auction.security.JwtTokenProvider;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@SuppressWarnings("null")
@RequestMapping("/api/artworks")
@CrossOrigin(origins = "*")
public class ArtworkController {

    @Autowired
    private ArtworkService artworkService;
    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @GetMapping
    public ResponseEntity<List<ArtworkDto>> getAllArtworks() {
        return ResponseEntity.ok(artworkService.getAllArtworks());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ArtworkDto> getArtworkById(@PathVariable @NonNull String id) {
        return ResponseEntity.ok(artworkService.getArtworkById(id));
    }

    @GetMapping("/artist/{artistId}")
    public ResponseEntity<List<ArtworkDto>> getByArtist(@PathVariable @NonNull String artistId) {
        return ResponseEntity.ok(artworkService.getArtworksByArtist(artistId));
    }

    @GetMapping("/search")
    public ResponseEntity<List<ArtworkDto>> search(@RequestParam @NonNull String title) {
        return ResponseEntity.ok(artworkService.searchArtworks(title));
    }

    @PostMapping
    @PreAuthorize("hasRole('ARTIST')")
    public ResponseEntity<ArtworkDto> createArtwork(@Valid @RequestBody ArtworkCreateRequest req,
            @RequestHeader("Authorization") @NonNull String authHeader) {
        Claims claims = jwtTokenProvider.extractClaims(authHeader.substring(7));
        String artistId = claims.get("userId", String.class);
        String artistName = claims.get("fullName", String.class);
        return ResponseEntity.ok(artworkService.createArtwork(req, artistId, artistName));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ARTIST')")
    public ResponseEntity<ArtworkDto> updateArtwork(@PathVariable @NonNull String id,
            @Valid @RequestBody ArtworkCreateRequest req,
            @RequestHeader("Authorization") @NonNull String authHeader) {
        Claims claims = jwtTokenProvider.extractClaims(authHeader.substring(7));
        String artistId = claims.get("userId", String.class);
        return ResponseEntity.ok(artworkService.updateArtwork(id, req, artistId));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ARTIST','ADMIN','EMPLOYEE')")
    public ResponseEntity<Map<String, String>> deleteArtwork(@PathVariable @NonNull String id,
            @RequestHeader("Authorization") @NonNull String authHeader) {
        Claims claims = jwtTokenProvider.extractClaims(authHeader.substring(7));
        String requesterId = claims.get("userId", String.class);
        String role = claims.get("role", String.class);
        boolean staffOverride = "ADMIN".equals(role) || "EMPLOYEE".equals(role);
        artworkService.deleteArtwork(id, requesterId, staffOverride);
        return ResponseEntity.ok(Map.of("message", "Artwork deleted"));
    }
}