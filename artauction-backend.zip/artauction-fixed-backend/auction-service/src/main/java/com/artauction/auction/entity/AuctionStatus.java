package com.artauction.auction.entity;

public enum AuctionStatus {
    SCHEDULED,
    ACTIVE,
    ENDED,
    CANCELLED
}
