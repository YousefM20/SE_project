package com.artauction.auction.dto;

import com.artauction.auction.entity.Bid;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class BidDto {
    private String id;
    private String auctionId;
    private String bidderId;
    private String bidderName;
    private BigDecimal amount;
    private LocalDateTime placedAt;

    public static BidDto fromEntity(Bid b) {
        BidDto d = new BidDto();
        d.id = b.getId(); d.auctionId = b.getAuctionId();
        d.bidderId = b.getBidderId(); d.bidderName = b.getBidderName();
        d.amount = b.getAmount(); d.placedAt = b.getPlacedAt();
        return d;
    }

    public String getId() { return id; }
    public String getAuctionId() { return auctionId; }
    public String getBidderId() { return bidderId; }
    public String getBidderName() { return bidderName; }
    public BigDecimal getAmount() { return amount; }
    public LocalDateTime getPlacedAt() { return placedAt; }
    public void setId(String id) { this.id = id; }
    public void setAuctionId(String v) { this.auctionId = v; }
    public void setBidderId(String v) { this.bidderId = v; }
    public void setBidderName(String v) { this.bidderName = v; }
    public void setAmount(BigDecimal v) { this.amount = v; }
    public void setPlacedAt(LocalDateTime v) { this.placedAt = v; }
}
