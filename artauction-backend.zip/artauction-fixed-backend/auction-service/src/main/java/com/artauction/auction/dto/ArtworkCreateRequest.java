package com.artauction.auction.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

public class ArtworkCreateRequest {
    @NotBlank(message = "Title is required")
    private String title;
    private String description;
    @NotBlank(message = "Medium is required")
    private String medium;
    private String dimensions;
    private Integer yearCreated;
    @NotNull @DecimalMin("0.01")
    private BigDecimal startingPrice;
    private String imageUrl;

    public String getTitle() { return title; }
    public void setTitle(String t) { this.title = t; }
    public String getDescription() { return description; }
    public void setDescription(String d) { this.description = d; }
    public String getMedium() { return medium; }
    public void setMedium(String m) { this.medium = m; }
    public String getDimensions() { return dimensions; }
    public void setDimensions(String d) { this.dimensions = d; }
    public Integer getYearCreated() { return yearCreated; }
    public void setYearCreated(Integer y) { this.yearCreated = y; }
    public BigDecimal getStartingPrice() { return startingPrice; }
    public void setStartingPrice(BigDecimal p) { this.startingPrice = p; }
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String i) { this.imageUrl = i; }
}
