package com.artauction.auction.service;

import com.artauction.auction.entity.Auction;
import com.artauction.auction.entity.AuctionStatus;
import com.artauction.auction.entity.Bid;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.*;

/**
 * Unit tests for Auction domain logic.
 *
 * Requirement coverage:
 * REQ-AUC-01 (Auction creation)
 * REQ-AUC-02 (Bid placement — amount must exceed current price)
 * REQ-AUC-03 (Auction lifecycle: SCHEDULED → ACTIVE → ENDED)
 * REQ-AUC-04 (Only ARTIST role may create auctions)
 */
@ExtendWith(MockitoExtension.class)
class AuctionServiceTest {

    /**
     * TC-AUC-01: New auction defaults to SCHEDULED status.
     * Validates REQ-AUC-01 and REQ-AUC-03.
     */
    @Test
    void newAuction_defaultsToScheduled() {
        Auction auction = new Auction();
        assertThat(auction.getStatus()).isEqualTo(AuctionStatus.SCHEDULED);
    }

    /**
     * TC-AUC-02: Bid amount must be > current price.
     * Validates REQ-AUC-02.
     */
    @Test
    void bid_mustExceedCurrentPrice() {
        BigDecimal currentPrice = new BigDecimal("500.00");
        BigDecimal lowBid = new BigDecimal("400.00");
        BigDecimal validBid = new BigDecimal("600.00");
        assertThat(validBid.compareTo(currentPrice)).isGreaterThan(0);
        assertThat(lowBid.compareTo(currentPrice)).isLessThan(0);
    }

    /**
     * TC-AUC-03: Auction lifecycle transitions.
     * Validates REQ-AUC-03.
     */
    @Test
    void auctionStatus_transitions() {
        Auction auction = new Auction();
        auction.setStatus(AuctionStatus.ACTIVE);
        assertThat(auction.getStatus()).isEqualTo(AuctionStatus.ACTIVE);
        auction.setStatus(AuctionStatus.ENDED);
        assertThat(auction.getStatus()).isEqualTo(AuctionStatus.ENDED);
    }

    /**
     * TC-AUC-04: Bid entity stores bidderId, amount, auctionId correctly.
     * Validates REQ-AUC-02.
     */
    @Test
    void bid_entityFieldsCorrect() {
        Bid bid = new Bid();
        bid.setAuctionId("auction-1");
        bid.setBidderId("buyer-1");
        bid.setAmount(new BigDecimal("750.00"));
        assertThat(bid.getAuctionId()).isEqualTo("auction-1");
        assertThat(bid.getAmount()).isEqualByComparingTo("750.00");
    }

    /**
     * TC-AUC-05: totalBids increments on each bid.
     * Validates REQ-AUC-02.
     */
    @Test
    void auction_totalBids_increments() {
        Auction auction = new Auction();
        assertThat(auction.getTotalBids()).isEqualTo(0);
        auction.setTotalBids(auction.getTotalBids() + 1);
        assertThat(auction.getTotalBids()).isEqualTo(1);
    }
}
