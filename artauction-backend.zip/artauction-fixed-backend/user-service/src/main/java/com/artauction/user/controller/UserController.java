package com.artauction.user.controller;

import com.artauction.user.dto.UpdateProfileRequest;
import com.artauction.user.dto.UserDto;
import com.artauction.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "*")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','EMPLOYEE')")
    public ResponseEntity<List<UserDto>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @GetMapping("/me")
    public ResponseEntity<UserDto> getCurrentUser(Principal principal) {
        return ResponseEntity.ok(userService.getUserByEmail(principal.getName()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserDto> getUserById(@PathVariable String id) {
        return ResponseEntity.ok(userService.getUserById(id));
    }

    /** Returns ALL pending users (any role) — used by admin dashboard */
    @GetMapping("/pending")
    @PreAuthorize("hasAnyRole('ADMIN','EMPLOYEE')")
    public ResponseEntity<List<UserDto>> getPendingUsers() {
        return ResponseEntity.ok(userService.getPendingArtists());
    }

    /** Legacy endpoint kept for backward compatibility */
    @GetMapping("/artists/pending")
    @PreAuthorize("hasAnyRole('ADMIN','EMPLOYEE')")
    public ResponseEntity<List<UserDto>> getPendingArtists() {
        return ResponseEntity.ok(userService.getPendingArtists());
    }

    /** Approve any user (artist, buyer, etc.) */
    @PutMapping("/artists/{id}/approve")
    @PreAuthorize("hasAnyRole('ADMIN','EMPLOYEE')")
    public ResponseEntity<UserDto> approveUser(@PathVariable String id) {
        return ResponseEntity.ok(userService.approveArtist(id));
    }

    @PutMapping("/me")
    public ResponseEntity<UserDto> updateMyProfile(Principal principal,
                                                    @RequestBody UpdateProfileRequest request) {
        UserDto current = userService.getUserByEmail(principal.getName());
        return ResponseEntity.ok(userService.updateProfile(current.getId(), request));
    }

    @PutMapping("/{id}/toggle-status")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<UserDto> toggleUserStatus(@PathVariable String id) {
        return ResponseEntity.ok(userService.toggleUserStatus(id));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Map<String, String>> deleteUser(@PathVariable String id) {
        userService.deleteUser(id);
        return ResponseEntity.ok(Map.of("message", "User deleted successfully"));
    }
}
