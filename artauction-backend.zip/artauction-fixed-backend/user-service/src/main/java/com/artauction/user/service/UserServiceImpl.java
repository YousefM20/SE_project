package com.artauction.user.service;

import com.artauction.user.client.NotificationServiceClient;
import com.artauction.user.dto.*;
import com.artauction.user.entity.Role;
import com.artauction.user.entity.User;
import com.artauction.user.exception.EmailAlreadyExistsException;
import com.artauction.user.exception.UserNotFoundException;
import com.artauction.user.repository.UserRepository;
import com.artauction.user.security.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Transactional
public class UserServiceImpl implements UserService {

    @Autowired private UserRepository userRepository;
    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private JwtTokenProvider jwtTokenProvider;
    @Autowired private AuthenticationManager authenticationManager;
    @Autowired private NotificationServiceClient notificationClient;

    @Override
    public LoginResponse register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new EmailAlreadyExistsException("Email already in use: " + request.getEmail());
        }

        User user = new User();
        user.setEmail(request.getEmail());
        user.setFullName(request.getFullName());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setBio(request.getBio());

        Role role = request.getRole() != null ? request.getRole() : Role.BUYER;
        user.setRole(role);

        // ALL new users require admin approval
        user.setApproved(false);
        user = userRepository.save(user);

        // Fire WELCOME notification + email
        try {
            notificationClient.sendNotification(Map.of(
                    "type",      "WELCOME",
                    "userId",    user.getId(),
                    "userEmail", user.getEmail(),
                    "userName",  user.getFullName(),
                    "message",   "Welcome to ArtAuction, " + user.getFullName()
                                 + "! Your account is pending admin approval."
            ));
        } catch (Exception ignored) {}

        String token = jwtTokenProvider.generateToken(user);
        return new LoginResponse(token, user.getId(), user.getEmail(),
                user.getFullName(), user.getRole().name());
    }

    @Override
    public LoginResponse login(LoginRequest request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new UserNotFoundException("User not found"));

        if (!user.isApproved()) {
            throw new RuntimeException(
                    "Your account is pending admin approval. Please wait for an admin to approve your registration.");
        }

        // Fire LOGIN notification + email
        try {
            notificationClient.sendNotification(Map.of(
                    "type",      "LOGIN",
                    "userId",    user.getId(),
                    "userEmail", user.getEmail(),
                    "userName",  user.getFullName(),
                    "message",   "You successfully logged in to ArtAuction."
            ));
        } catch (Exception ignored) {}

        String token = jwtTokenProvider.generateToken(user);
        return new LoginResponse(token, user.getId(), user.getEmail(),
                user.getFullName(), user.getRole().name());
    }

    @Override
    @Transactional(readOnly = true)
    public UserDto getUserById(String id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found: " + id));
        return UserDto.fromEntity(user);
    }

    @Override
    @Transactional(readOnly = true)
    public UserDto getUserByEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UserNotFoundException("User not found: " + email));
        return UserDto.fromEntity(user);
    }

    @Override
    @Transactional(readOnly = true)
    public List<UserDto> getAllUsers() {
        return userRepository.findAll().stream()
                .map(UserDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<UserDto> getPendingArtists() {
        return userRepository.findByApproved(false).stream()
                .map(UserDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    public UserDto approveArtist(String userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found: " + userId));
        user.setApproved(true);
        User saved = userRepository.save(user);

        // Fire ACCOUNT_APPROVED notification + email
        try {
            notificationClient.sendNotification(Map.of(
                    "type",      "ACCOUNT_APPROVED",
                    "userId",    saved.getId(),
                    "userEmail", saved.getEmail(),
                    "userName",  saved.getFullName(),
                    "message",   "Your ArtAuction account has been approved! You can now log in."
            ));
        } catch (Exception ignored) {}

        return UserDto.fromEntity(saved);
    }

    @Override
    public UserDto updateProfile(String userId, UpdateProfileRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found: " + userId));
        if (request.getFullName() != null && !request.getFullName().isBlank()) {
            user.setFullName(request.getFullName());
        }
        if (request.getBio() != null) {
            user.setBio(request.getBio());
        }
        return UserDto.fromEntity(userRepository.save(user));
    }

    @Override
    public void deleteUser(String userId) {
        if (!userRepository.existsById(userId)) {
            throw new UserNotFoundException("User not found: " + userId);
        }
        userRepository.deleteById(userId);
    }

    @Override
    public UserDto toggleUserStatus(String userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found: " + userId));
        user.setActive(!user.isActive());
        return UserDto.fromEntity(userRepository.save(user));
    }
}
