package com.artauction.user.service;

import com.artauction.user.dto.*;
import java.util.List;

public interface UserService {
    LoginResponse register(RegisterRequest request);
    LoginResponse login(LoginRequest request);
    UserDto getUserById(String id);
    UserDto getUserByEmail(String email);
    List<UserDto> getAllUsers();
    List<UserDto> getPendingArtists();
    UserDto approveArtist(String artistId);
    UserDto updateProfile(String userId, UpdateProfileRequest request);
    void deleteUser(String userId);
    UserDto toggleUserStatus(String userId);
}
