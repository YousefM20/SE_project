package com.artauction.user.entity;

public enum Role {
    ADMIN,
    EMPLOYEE,
    ARTIST,
    BUYER
}
