# ArtAuction — Microservices Platform
### Spring Boot 3 · Spring Cloud · PostgreSQL · Docker Compose

---

## Architecture

```
Postman / Browser
       │
       ▼
  API Gateway  :8080   ← JWT GlobalFilter (validates every request)
       │
   ┌───┼──────────────────┐
   ▼   ▼                  ▼
User   Auction       Notification
:8081  :8082             :8083
   │      │                 │
   └──────┴────────┬────────┘
                   ▼
           PostgreSQL :5432
      (4 isolated databases)

           Eureka :8761
      (service discovery)
```

## Functional Modules
| # | Module | Role | Endpoints |
|---|--------|------|-----------|
| 1 | User Management | Auth, roles, artist approval | `/api/auth/**`, `/api/users/**` |
| 2 | Artwork Catalogue | Artists list artworks | `/api/artworks/**` |
| 3 | Auction Management | Create/schedule/cancel | `/api/auctions/**` |
| 4 | Bidding System | Place bids, history | `/api/bids/**` |
| 5 | Notifications | Events, read/unread | `/api/notifications/**` |

## Roles & Permissions
| Role | Permissions |
|------|-------------|
| **ADMIN** | Full control: delete users, toggle status, all staff capabilities |
| **EMPLOYEE** | Staff: list users, view/approve pending artists, broadcast notifications, cancel any auction / delete any artwork (moderation), view own bid history |
| **ARTIST** | Upload artworks, create auctions, cancel own auctions |
| **BUYER** | Place bids, view auctions, manage own notifications |

---

## Prerequisites
- Docker Desktop ≥ 4.x (with Compose v2)
- 6 GB RAM recommended (5 services + Postgres)
- Ports free: 5432, 8080, 8081, 8082, 8083, 8761

---

## ▶ Run in 3 Commands

```bash
cd artauction

# Build all images and start (first time: ~5-8 min for Maven downloads)
docker compose up --build

# Or run in background
docker compose up --build -d
```

**Wait ~60 seconds** for all services to register with Eureka, then test.

### Stop
```bash
docker compose down          # stop containers
docker compose down -v       # stop + delete database volumes
```

---

## Test All Endpoints (Postman / curl)

> **Base URL**: `http://localhost:8080`  (everything goes through the gateway)

### 1. Register Users

```bash
# Register ADMIN
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"fullName":"Admin User","email":"admin@art.com","password":"admin123","role":"ADMIN"}'

# Register ARTIST
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"fullName":"Picasso Jr","email":"artist@art.com","password":"artist123","role":"ARTIST","bio":"Modern abstract painter"}'

# Register BUYER
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"fullName":"Rich Buyer","email":"buyer@art.com","password":"buyer123","role":"BUYER"}'

# Register EMPLOYEE (staff — can approve artists, list users, moderate auctions)
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"fullName":"Gallery Staff","email":"staff@art.com","password":"staff123","role":"EMPLOYEE"}'
```

> **Save the `token`** from each response.

After `docker compose up --build`, wait for Eureka registration, then confirm the gateway allows **unauthenticated GET** to `http://localhost:8080/api/artworks` and `http://localhost:8080/api/auctions` (same as auction-service public catalog).

### 2. Login

```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"artist@art.com","password":"artist123"}'
```

### 3. Upload Artwork (ARTIST)

```bash
curl -X POST http://localhost:8080/api/artworks \
  -H "Authorization: Bearer ARTIST_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Sunrise Over Cairo",
    "description": "Oil painting capturing morning light",
    "medium": "Oil on Canvas",
    "dimensions": "80x60cm",
    "yearCreated": 2024,
    "startingPrice": 500.00
  }'
```

> **Save the artwork `id`**.

### 4. Create Auction (ARTIST)

```bash
curl -X POST http://localhost:8080/api/auctions \
  -H "Authorization: Bearer ARTIST_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "artworkId": "ARTWORK_ID_HERE",
    "startTime": "2024-01-01T00:00:00",
    "endTime": "2099-12-31T23:59:59",
    "reservePrice": 400.00
  }'
```

> Use a `startTime` in the past to make it ACTIVE immediately.
> **Save the auction `id`**.

### 5. Place a Bid (BUYER)

```bash
curl -X POST http://localhost:8080/api/bids/auction/AUCTION_ID_HERE \
  -H "Authorization: Bearer BUYER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"amount": 750.00}'
```

### 6. View Active Auctions (Public)

```bash
curl http://localhost:8080/api/auctions/active
```

### 7. View Bid History (Public)

```bash
curl http://localhost:8080/api/bids/auction/AUCTION_ID_HERE
```

### 8. Admin — Approve Artist (ADMIN)

```bash
# Get pending artists
curl -H "Authorization: Bearer ADMIN_TOKEN" \
  http://localhost:8080/api/users/artists/pending

# Approve
curl -X PUT -H "Authorization: Bearer ADMIN_TOKEN" \
  http://localhost:8080/api/users/artists/ARTIST_ID/approve
```

### 9. Get Notifications

```bash
# All (Admin only)
curl -H "Authorization: Bearer ADMIN_TOKEN" \
  http://localhost:8080/api/notifications/all

# My notifications (any role)
curl -H "Authorization: Bearer BUYER_TOKEN" \
  http://localhost:8080/api/notifications/my

# Mark as read
curl -X PUT -H "Authorization: Bearer BUYER_TOKEN" \
  http://localhost:8080/api/notifications/NOTIF_ID/read
```

---

## 🔍 Monitoring

| URL | Description |
|-----|-------------|
| `http://localhost:8761` | Eureka Dashboard — see all registered services |
| `http://localhost:8081/swagger-ui.html` | User Service API docs |
| `http://localhost:8082/swagger-ui.html` | Auction Service API docs |
| `http://localhost:8083/swagger-ui.html` | Notification Service API docs |
| `http://localhost:8081/actuator/health` | User service health |
| `http://localhost:8082/actuator/health` | Auction service health |

---

## Project Structure

```
artauction/
├── docker-compose.yml
├── init-db.sql                    ← creates 3 databases on first boot
├── eureka-server/                 ← Service registry (port 8761)
├── api-gateway/                   ← JWT validation + routing (port 8080)
├── user-service/                  ← Auth, users, roles (port 8081)
│   └── src/main/java/com/artauction/user/
│       ├── controller/            AuthController, UserController
│       ├── service/               UserServiceImpl
│       ├── security/              JwtTokenProvider, JwtAuthFilter
│       ├── aspect/                LoggingAspect  ← AOP
│       └── entity/                User, Role
├── auction-service/               ← Artworks, auctions, bids (port 8082)
│   └── src/main/java/com/artauction/auction/
│       ├── controller/            ArtworkController, AuctionController, BidController
│       ├── service/               ArtworkService, AuctionService, BidService
│       ├── scheduler/             AuctionScheduler  ← auto start/close
│       ├── aspect/                LoggingAspect  ← AOP
│       ├── client/                NotificationServiceClient (Feign)
│       └── entity/                Artwork, Auction, Bid
└── notification-service/          ← Notifications (port 8083)
    └── src/main/java/com/artauction/notification/
        ├── controller/            NotificationController
        ├── service/               NotificationService
        └── aspect/                LoggingAspect  ← AOP
```

---

## Implementation Highlights

### AOP (Aspect-Oriented Programming)
All three business services have a `LoggingAspect` that intercepts every service and controller method, logging entry, exit time, and exceptions — without touching business logic.

### Spring Cloud Components
- **Eureka Server**: all services self-register on startup
- **API Gateway**: Spring Cloud Gateway with reactive JWT GlobalFilter
- **OpenFeign**: auction-service calls notification-service for event delivery
- **Load Balancer**: `lb://service-name` routing in gateway config

### Scheduler (AuctionScheduler)
Runs every 30 seconds to:
1. Activate `SCHEDULED` auctions whose `startTime` has passed
2. Close `ACTIVE` auctions whose `endTime` has passed and set the winner

### RBAC (Role-Based Access Control)
- Enforced at two layers: API Gateway (JWT presence) + `@PreAuthorize` in controllers
- Three roles: `ADMIN`, `ARTIST`, `BUYER` — each with distinct permissions
- Artists require admin approval before they can log in

---

## Troubleshooting

**Services not appearing in Eureka?**
```bash
docker compose logs eureka-server
docker compose logs user-service
```
Wait 30–60 seconds after startup; Eureka registration has a heartbeat delay.

**Database connection refused?**
```bash
docker compose logs postgres
```
The init-db.sql creates all three databases on first boot — check it ran successfully.

**401 Unauthorized on all requests?**
Make sure you're passing `Authorization: Bearer TOKEN` header. Tokens expire after 24h.

**Rebuild after code changes:**
```bash
docker compose down
docker compose up --build
```
