package com.artauction.notification.dto;

public class CreateNotificationRequest {
    private String type;
    private String message;
    private String auctionId;
    private String userId;      // optional — null means broadcast

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getAuctionId() { return auctionId; }
    public void setAuctionId(String auctionId) { this.auctionId = auctionId; }
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
}
