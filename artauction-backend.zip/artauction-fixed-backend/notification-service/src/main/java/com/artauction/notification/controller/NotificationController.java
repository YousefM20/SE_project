package com.artauction.notification.controller;

import com.artauction.notification.dto.CreateNotificationRequest;
import com.artauction.notification.dto.NotificationDto;
import com.artauction.notification.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/notifications")
@CrossOrigin(origins = "*")
public class NotificationController {

    @Autowired private NotificationService notificationService;

    /** Internal endpoint — called by auction-service Feign client (no auth required) */
    @PostMapping
    public ResponseEntity<Void> receiveNotification(@RequestBody Map<String, String> payload) {
        notificationService.createFromMap(payload);
        return ResponseEntity.ok().build();
    }

    /** Admin: see all notifications */
    @GetMapping("/all")
    @PreAuthorize("hasAnyRole('ADMIN','EMPLOYEE')")
    public ResponseEntity<List<NotificationDto>> getAllNotifications() {
        return ResponseEntity.ok(notificationService.getAll());
    }

    /** Current user: get their notifications */
    @GetMapping("/my")
    public ResponseEntity<List<NotificationDto>> getMyNotifications() {
        String userId = getCredential();
        return ResponseEntity.ok(notificationService.getForUser(userId));
    }

    /** Current user: get only unread */
    @GetMapping("/my/unread")
    public ResponseEntity<List<NotificationDto>> getMyUnread() {
        String userId = getCredential();
        return ResponseEntity.ok(notificationService.getUnreadForUser(userId));
    }

    /** Current user: unread count */
    @GetMapping("/my/unread-count")
    public ResponseEntity<Map<String, Long>> getUnreadCount() {
        String userId = getCredential();
        return ResponseEntity.ok(Map.of("count", notificationService.countUnread(userId)));
    }

    /** Mark single notification as read */
    @PutMapping("/{id}/read")
    public ResponseEntity<NotificationDto> markRead(@PathVariable String id) {
        return ResponseEntity.ok(notificationService.markAsRead(id));
    }

    /** Mark all as read for current user */
    @PutMapping("/my/read-all")
    public ResponseEntity<Map<String, String>> markAllRead() {
        String userId = getCredential();
        notificationService.markAllReadForUser(userId);
        return ResponseEntity.ok(Map.of("message", "All notifications marked as read"));
    }

    /** Admin: create manual notification */
    @PostMapping("/create")
    @PreAuthorize("hasAnyRole('ADMIN','EMPLOYEE')")
    public ResponseEntity<NotificationDto> createManual(@RequestBody CreateNotificationRequest req) {
        return ResponseEntity.ok(notificationService.create(req));
    }

    private String getCredential() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        // credentials holds the userId (set in JwtAuthenticationFilter)
        return (String) auth.getCredentials();
    }
}
