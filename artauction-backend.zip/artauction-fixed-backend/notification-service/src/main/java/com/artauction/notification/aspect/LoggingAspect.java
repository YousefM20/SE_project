package com.artauction.notification.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    private static final Logger log = LoggerFactory.getLogger(LoggingAspect.class);

    @Pointcut("within(com.artauction.notification.service..*) || within(com.artauction.notification.controller..*)")
    public void appPointcut() {}

    @Around("appPointcut()")
    public Object logAround(ProceedingJoinPoint pjp) throws Throwable {
        String cls    = pjp.getSignature().getDeclaringTypeName();
        String method = pjp.getSignature().getName();
        log.info("[AOP] → {}.{}()", cls, method);
        long t = System.currentTimeMillis();
        try {
            Object result = pjp.proceed();
            log.info("[AOP] ← {}.{}() [{}ms]", cls, method, System.currentTimeMillis() - t);
            return result;
        } catch (Throwable ex) {
            log.error("[AOP] ✗ {}.{}() threw: {}", cls, method, ex.getMessage());
            throw ex;
        }
    }
}
