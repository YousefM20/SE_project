package com.artauction.notification.service;

import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * Sends HTML emails via Gmail SMTP.
 * All sends are @Async so they never block the calling thread.
 */
@Service
public class EmailService {

    private static final Logger log = LoggerFactory.getLogger(EmailService.class);

    @Autowired
    private JavaMailSender mailSender;

    @Value("${app.mail.from}")
    private String fromAddress;

    @Value("${app.mail.enabled:true}")
    private boolean mailEnabled;

    // ─────────────────────────────────────────────────────────────────────────
    //  Public send methods — one per notification type
    // ─────────────────────────────────────────────────────────────────────────

    @Async
    public void sendWelcomeEmail(String toEmail, String fullName) {
        String subject = "Welcome to ArtAuction 🎨";
        String html = buildHtml(
                "Welcome, " + fullName + "!",
                "Thank you for registering at <b>ArtAuction</b>.<br><br>" +
                "Your account is currently <b>pending admin approval</b>. " +
                "You will be able to log in as soon as an administrator reviews your registration.<br><br>" +
                "We'll notify you once your account is approved.",
                null, null
        );
        send(toEmail, subject, html);
    }

    @Async
    public void sendAccountApprovedEmail(String toEmail, String fullName) {
        String subject = "✅ Your ArtAuction Account is Approved!";
        String html = buildHtml(
                "You're in, " + fullName + "!",
                "Great news — your <b>ArtAuction</b> account has been approved by an administrator.<br><br>" +
                "You can now log in and start exploring auctions.",
                "Log In Now", "http://localhost:3000/login"
        );
        send(toEmail, subject, html);
    }

    @Async
    public void sendLoginEmail(String toEmail, String fullName) {
        String subject = "New login to your ArtAuction account";
        String html = buildHtml(
                "Hello, " + fullName + "!",
                "We noticed a new login to your <b>ArtAuction</b> account.<br><br>" +
                "If this was you, no action is needed. If you did not log in, " +
                "please contact support immediately.",
                null, null
        );
        send(toEmail, subject, html);
    }

    @Async
    public void sendNewBidEmail(String toEmail, String artworkTitle,
                                String bidderName, String amount) {
        String subject = "New bid on your auction — " + artworkTitle;
        String html = buildHtml(
                "New Bid Received!",
                "<b>" + bidderName + "</b> placed a bid of <b>$" + amount + "</b> " +
                "on your auction for <b>" + artworkTitle + "</b>.<br><br>" +
                "Head to the auction page to keep track of the bidding.",
                "View Auction", "http://localhost:3000/auctions"
        );
        send(toEmail, subject, html);
    }

    @Async
    public void sendAuctionCreatedEmail(String toEmail, String artworkTitle) {
        String subject = "Your auction is live — " + artworkTitle;
        String html = buildHtml(
                "Auction Started!",
                "Your auction for <b>" + artworkTitle + "</b> is now live on ArtAuction.<br><br>" +
                "Bidders can start placing bids right away.",
                "View Auction", "http://localhost:3000/auctions"
        );
        send(toEmail, subject, html);
    }

    @Async
    public void sendAuctionEndedWinnerEmail(String toEmail, String winnerName,
                                             String artworkTitle, String amount) {
        String subject = "🏆 You won the auction for " + artworkTitle + "!";
        String html = buildHtml(
                "Congratulations, " + winnerName + "!",
                "You won the auction for <b>" + artworkTitle + "</b> " +
                "with a winning bid of <b>$" + amount + "</b>.<br><br>" +
                "The artist will be in touch to arrange delivery.",
                "View My Bids", "http://localhost:3000/profile"
        );
        send(toEmail, subject, html);
    }

    @Async
    public void sendAuctionEndedArtistEmail(String toEmail, String artworkTitle,
                                             String winnerName, String amount) {
        String subject = "Your auction ended — " + artworkTitle;
        String html = buildHtml(
                "Auction Ended!",
                "Your auction for <b>" + artworkTitle + "</b> has closed.<br><br>" +
                "The winning bid was <b>$" + amount + "</b> by <b>" + winnerName + "</b>.",
                "View My Auctions", "http://localhost:3000/profile"
        );
        send(toEmail, subject, html);
    }

    @Async
    public void sendGenericEmail(String toEmail, String subject, String message) {
        String html = buildHtml("ArtAuction Notification", message, null, null);
        send(toEmail, subject, html);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Core send helper
    // ─────────────────────────────────────────────────────────────────────────

    private void send(String to, String subject, String htmlBody) {
        if (!mailEnabled) {
            log.info("[EMAIL DISABLED] Would have sent '{}' to {}", subject, to);
            return;
        }
        if (to == null || to.isBlank()) {
            log.warn("[EMAIL] Skipping send — recipient address is empty. Subject: {}", subject);
            return;
        }
        try {
            MimeMessage msg = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(msg, true, "UTF-8");
            helper.setFrom(fromAddress);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(htmlBody, true);   // true = HTML
            mailSender.send(msg);
            log.info("[EMAIL] Sent '{}' to {}", subject, to);
        } catch (Exception e) {
            log.error("[EMAIL] Failed to send '{}' to {} — {}", subject, to, e.getMessage());
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  HTML template builder
    // ─────────────────────────────────────────────────────────────────────────

    private String buildHtml(String heading, String body,
                              String buttonText, String buttonUrl) {
        String button = "";
        if (buttonText != null && buttonUrl != null) {
            button = "<br><a href='" + buttonUrl + "' style='" +
                     "display:inline-block;margin-top:16px;padding:12px 28px;" +
                     "background:#6366f1;color:#fff;text-decoration:none;" +
                     "border-radius:8px;font-weight:600;font-size:15px;'>" +
                     buttonText + "</a>";
        }
        return "<!DOCTYPE html><html><body style='margin:0;padding:0;background:#f4f4f5;font-family:Arial,sans-serif;'>" +
               "<table width='100%' cellpadding='0' cellspacing='0' style='background:#f4f4f5;padding:40px 0;'><tr><td align='center'>" +
               "<table width='560' cellpadding='0' cellspacing='0' style='background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.08);'>" +
               // Header
               "<tr><td style='background:#6366f1;padding:28px 32px;'>" +
               "<span style='color:#fff;font-size:22px;font-weight:700;'>🎨 ArtAuction</span>" +
               "</td></tr>" +
               // Body
               "<tr><td style='padding:32px;color:#1a1a1a;'>" +
               "<h2 style='margin:0 0 16px;font-size:22px;color:#1a1a1a;'>" + heading + "</h2>" +
               "<p style='margin:0;font-size:15px;line-height:1.7;color:#444;'>" + body + "</p>" +
               button +
               "</td></tr>" +
               // Footer
               "<tr><td style='background:#f9fafb;padding:20px 32px;border-top:1px solid #e5e7eb;'>" +
               "<p style='margin:0;font-size:12px;color:#9ca3af;'>You received this email because you have an ArtAuction account. " +
               "This is an automated message — please do not reply.</p>" +
               "</td></tr>" +
               "</table></td></tr></table></body></html>";
    }
}
