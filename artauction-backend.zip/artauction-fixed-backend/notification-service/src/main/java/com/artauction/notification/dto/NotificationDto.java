package com.artauction.notification.dto;

import com.artauction.notification.entity.Notification;
import java.time.LocalDateTime;

public class NotificationDto {
    private String id;
    private String type;
    private String message;
    private String auctionId;
    private String userId;
    private boolean read;
    private LocalDateTime createdAt;

    public static NotificationDto fromEntity(Notification n) {
        NotificationDto d = new NotificationDto();
        d.id = n.getId(); d.type = n.getType(); d.message = n.getMessage();
        d.auctionId = n.getAuctionId(); d.userId = n.getUserId();
        d.read = n.isRead(); d.createdAt = n.getCreatedAt();
        return d;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getAuctionId() { return auctionId; }
    public void setAuctionId(String auctionId) { this.auctionId = auctionId; }
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
    public boolean isRead() { return read; }
    public void setRead(boolean read) { this.read = read; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
