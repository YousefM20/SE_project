package com.artauction.notification.service;

import com.artauction.notification.dto.CreateNotificationRequest;
import com.artauction.notification.dto.NotificationDto;
import com.artauction.notification.entity.Notification;
import com.artauction.notification.repository.NotificationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Transactional
public class NotificationService {

    private static final Logger log = LoggerFactory.getLogger(NotificationService.class);

    @Autowired private NotificationRepository notificationRepository;
    @Autowired private EmailService emailService;

    /**
     * Called by user-service and auction-service via Feign.
     *
     * Expected payload keys:
     *   type        — WELCOME | LOGIN | ACCOUNT_APPROVED | NEW_BID |
     *                 AUCTION_CREATED | AUCTION_ENDED | GENERAL
     *   message     — human-readable text (stored in DB)
     *   userId      — recipient user ID (optional, null = broadcast)
     *   userEmail   — recipient email address (required for email delivery)
     *   userName    — recipient full name
     *   auctionId   — related auction ID (optional)
     *   artworkTitle — artwork name (for auction events)
     *   bidderName  — bidder's name (for NEW_BID)
     *   amount      — bid/winning amount (for NEW_BID / AUCTION_ENDED)
     *   winnerName  — winner's name (for AUCTION_ENDED sent to artist)
     *   artistEmail — artist email (for AUCTION_ENDED dual-notify)
     *   artistName  — artist name  (for AUCTION_ENDED dual-notify)
     */
    public NotificationDto createFromMap(Map<String, String> payload) {
        // 1. Persist in-app notification
        Notification n = new Notification();
        n.setType(payload.getOrDefault("type", "GENERAL"));
        n.setMessage(payload.getOrDefault("message", ""));
        n.setAuctionId(payload.get("auctionId"));
        n.setUserId(payload.get("userId"));
        NotificationDto saved = NotificationDto.fromEntity(notificationRepository.save(n));

        // 2. Send email asynchronously (never blocks the caller)
        dispatchEmail(payload);

        return saved;
    }

    /** Create via REST body (admin manual create) */
    public NotificationDto create(CreateNotificationRequest req) {
        Notification n = new Notification();
        n.setType(req.getType());
        n.setMessage(req.getMessage());
        n.setAuctionId(req.getAuctionId());
        n.setUserId(req.getUserId());
        return NotificationDto.fromEntity(notificationRepository.save(n));
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Email dispatch — routes by type
    // ─────────────────────────────────────────────────────────────────────────

    private void dispatchEmail(Map<String, String> p) {
        String type      = p.getOrDefault("type", "GENERAL");
        String email     = p.get("userEmail");
        String name      = p.getOrDefault("userName", "User");
        String artwork   = p.getOrDefault("artworkTitle", "your artwork");
        String bidder    = p.getOrDefault("bidderName", "A bidder");
        String amount    = p.getOrDefault("amount", "0");
        String winner    = p.getOrDefault("winnerName", "the winner");
        String artEmail  = p.get("artistEmail");
        String artName   = p.getOrDefault("artistName", "Artist");

        try {
            switch (type) {
                case "WELCOME" ->
                    emailService.sendWelcomeEmail(email, name);

                case "LOGIN" ->
                    emailService.sendLoginEmail(email, name);

                case "ACCOUNT_APPROVED" ->
                    emailService.sendAccountApprovedEmail(email, name);

                case "NEW_BID" ->
                    // Notify the auction owner (artistEmail) of the new bid
                    emailService.sendNewBidEmail(artEmail != null ? artEmail : email,
                            artwork, bidder, amount);

                case "AUCTION_CREATED" ->
                    emailService.sendAuctionCreatedEmail(email, artwork);

                case "AUCTION_ENDED" -> {
                    // Notify winner
                    emailService.sendAuctionEndedWinnerEmail(email, name, artwork, amount);
                    // Notify artist separately
                    if (artEmail != null) {
                        emailService.sendAuctionEndedArtistEmail(artEmail, artwork, winner, amount);
                    }
                }

                default ->
                    emailService.sendGenericEmail(email,
                            "ArtAuction — " + type, p.getOrDefault("message", ""));
            }
        } catch (Exception e) {
            // Email dispatch must never propagate — in-app notification was already saved
            log.error("[EMAIL DISPATCH] Error for type={}: {}", type, e.getMessage());
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Query methods (unchanged)
    // ─────────────────────────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public List<NotificationDto> getAll() {
        return notificationRepository.findAllByOrderByCreatedAtDesc()
                .stream().map(NotificationDto::fromEntity).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<NotificationDto> getForUser(String userId) {
        return notificationRepository.findByUserIdOrderByCreatedAtDesc(userId)
                .stream().map(NotificationDto::fromEntity).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<NotificationDto> getUnreadForUser(String userId) {
        return notificationRepository.findByUserIdAndReadFalseOrderByCreatedAtDesc(userId)
                .stream().map(NotificationDto::fromEntity).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public long countUnread(String userId) {
        return notificationRepository.countByUserIdAndReadFalse(userId);
    }

    public NotificationDto markAsRead(String notificationId) {
        Notification n = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new RuntimeException("Notification not found: " + notificationId));
        n.setRead(true);
        return NotificationDto.fromEntity(notificationRepository.save(n));
    }

    public void markAllReadForUser(String userId) {
        List<Notification> unread =
                notificationRepository.findByUserIdAndReadFalseOrderByCreatedAtDesc(userId);
        unread.forEach(n -> n.setRead(true));
        notificationRepository.saveAll(unread);
    }
}
