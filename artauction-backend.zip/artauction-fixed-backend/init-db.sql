-- Create databases for each microservice (idempotent — safe on restart)
SELECT 'CREATE DATABASE artauction_users'
  WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'artauction_users')\gexec

SELECT 'CREATE DATABASE artauction_auctions'
  WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'artauction_auctions')\gexec

SELECT 'CREATE DATABASE artauction_notifications'
  WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'artauction_notifications')\gexec

SELECT 'CREATE DATABASE artauction_watchlist'
  WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'artauction_watchlist')\gexec

