#!/bin/bash
# Creates multiple databases inside the single Postgres container
set -e

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" <<-EOSQL
    CREATE DATABASE artauction_users;
    CREATE DATABASE artauction_auctions;
    CREATE DATABASE artauction_notifications;
EOSQL

echo "All three databases created successfully."
