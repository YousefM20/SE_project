package com.artauction.watchlist.repository;

import com.artauction.watchlist.entity.TargetType;
import com.artauction.watchlist.entity.WatchlistItem;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface WatchlistRepository extends JpaRepository<WatchlistItem, String> {
    List<WatchlistItem> findByUserId(String userId);
    List<WatchlistItem> findByUserIdAndTargetType(String userId, TargetType targetType);
    Optional<WatchlistItem> findByUserIdAndTargetIdAndTargetType(String userId, String targetId, TargetType targetType);
    boolean existsByUserIdAndTargetIdAndTargetType(String userId, String targetId, TargetType targetType);
    void deleteByUserIdAndTargetIdAndTargetType(String userId, String targetId, TargetType targetType);
    long countByUserId(String userId);
}
