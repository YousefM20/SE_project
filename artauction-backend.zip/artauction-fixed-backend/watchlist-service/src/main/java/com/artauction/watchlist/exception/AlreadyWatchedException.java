package com.artauction.watchlist.exception;

public class AlreadyWatchedException extends RuntimeException {
    public AlreadyWatchedException(String message) { super(message); }
}
