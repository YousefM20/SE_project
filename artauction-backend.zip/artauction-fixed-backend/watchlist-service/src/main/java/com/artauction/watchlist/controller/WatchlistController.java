package com.artauction.watchlist.controller;

import com.artauction.watchlist.dto.AddWatchlistRequest;
import com.artauction.watchlist.dto.WatchlistItemDto;
import com.artauction.watchlist.entity.TargetType;
import com.artauction.watchlist.security.JwtTokenProvider;
import com.artauction.watchlist.service.WatchlistService;
import io.jsonwebtoken.Claims;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/watchlist")
@CrossOrigin(origins = "*")
public class WatchlistController {

    @Autowired private WatchlistService watchlistService;
    @Autowired private JwtTokenProvider jwtTokenProvider;

    /** Get authenticated user's full watchlist */
    @GetMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<WatchlistItemDto>> getMyWatchlist(
            @RequestHeader("Authorization") String authHeader) {
        String userId = extractUserId(authHeader);
        return ResponseEntity.ok(watchlistService.getWatchlistForUser(userId));
    }

    /** Filter watchlist by type: ARTWORK or AUCTION */
    @GetMapping("/filter")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<WatchlistItemDto>> getByType(
            @RequestHeader("Authorization") String authHeader,
            @RequestParam TargetType type) {
        String userId = extractUserId(authHeader);
        return ResponseEntity.ok(watchlistService.getWatchlistByType(userId, type));
    }

    /** Check if a specific item is watched */
    @GetMapping("/check")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Map<String, Boolean>> checkWatched(
            @RequestHeader("Authorization") String authHeader,
            @RequestParam String targetId,
            @RequestParam TargetType targetType) {
        String userId = extractUserId(authHeader);
        boolean watched = watchlistService.isWatched(userId, targetId, targetType);
        return ResponseEntity.ok(Map.of("watched", watched));
    }

    /** Get watchlist statistics */
    @GetMapping("/stats")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Map<String, Object>> getStats(
            @RequestHeader("Authorization") String authHeader) {
        String userId = extractUserId(authHeader);
        return ResponseEntity.ok(watchlistService.getWatchlistStats(userId));
    }

    /** Add an item to watchlist */
    @PostMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<WatchlistItemDto> addToWatchlist(
            @RequestHeader("Authorization") String authHeader,
            @Valid @RequestBody AddWatchlistRequest request) {
        String userId = extractUserId(authHeader);
        return ResponseEntity.ok(watchlistService.addToWatchlist(userId, request));
    }

    /** Remove an item from watchlist */
    @DeleteMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Map<String, String>> removeFromWatchlist(
            @RequestHeader("Authorization") String authHeader,
            @RequestParam String targetId,
            @RequestParam TargetType targetType) {
        String userId = extractUserId(authHeader);
        watchlistService.removeFromWatchlist(userId, targetId, targetType);
        return ResponseEntity.ok(Map.of("message", "Removed from watchlist"));
    }

    /** Admin: view all watchlist entries */
    @GetMapping("/admin/all")
    @PreAuthorize("hasAnyRole('ADMIN','EMPLOYEE')")
    public ResponseEntity<List<WatchlistItemDto>> getAllWatchlists() {
        return ResponseEntity.ok(watchlistService.getWatchlistForUser("*"));
    }

    private String extractUserId(String authHeader) {
        Claims claims = jwtTokenProvider.extractClaims(authHeader.substring(7));
        return claims.get("userId", String.class);
    }
}
