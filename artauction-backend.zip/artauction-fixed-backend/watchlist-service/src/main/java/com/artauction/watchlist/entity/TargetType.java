package com.artauction.watchlist.entity;

public enum TargetType {
    ARTWORK,
    AUCTION
}
