package com.artauction.watchlist.service;

import com.artauction.watchlist.dto.AddWatchlistRequest;
import com.artauction.watchlist.dto.WatchlistItemDto;
import com.artauction.watchlist.entity.TargetType;
import com.artauction.watchlist.entity.WatchlistItem;
import com.artauction.watchlist.exception.AlreadyWatchedException;
import com.artauction.watchlist.exception.WatchlistItemNotFoundException;
import com.artauction.watchlist.repository.WatchlistRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class WatchlistService {

    @Autowired
    private WatchlistRepository watchlistRepository;

    public List<WatchlistItemDto> getWatchlistForUser(String userId) {
        return watchlistRepository.findByUserId(userId)
                .stream().map(this::toDto).collect(Collectors.toList());
    }

    public List<WatchlistItemDto> getWatchlistByType(String userId, TargetType type) {
        return watchlistRepository.findByUserIdAndTargetType(userId, type)
                .stream().map(this::toDto).collect(Collectors.toList());
    }

    @Transactional
    public WatchlistItemDto addToWatchlist(String userId, AddWatchlistRequest request) {
        if (watchlistRepository.existsByUserIdAndTargetIdAndTargetType(
                userId, request.getTargetId(), request.getTargetType())) {
            throw new AlreadyWatchedException("Item already in watchlist");
        }
        WatchlistItem item = new WatchlistItem();
        item.setUserId(userId);
        item.setTargetId(request.getTargetId());
        item.setTargetType(request.getTargetType());
        item.setTitle(request.getTitle());
        return toDto(watchlistRepository.save(item));
    }

    @Transactional
    public void removeFromWatchlist(String userId, String targetId, TargetType targetType) {
        if (!watchlistRepository.existsByUserIdAndTargetIdAndTargetType(userId, targetId, targetType)) {
            throw new WatchlistItemNotFoundException("Watchlist item not found");
        }
        watchlistRepository.deleteByUserIdAndTargetIdAndTargetType(userId, targetId, targetType);
    }

    public boolean isWatched(String userId, String targetId, TargetType targetType) {
        return watchlistRepository.existsByUserIdAndTargetIdAndTargetType(userId, targetId, targetType);
    }

    public Map<String, Object> getWatchlistStats(String userId) {
        long total = watchlistRepository.countByUserId(userId);
        long artworks = watchlistRepository.findByUserIdAndTargetType(userId, TargetType.ARTWORK).size();
        long auctions = watchlistRepository.findByUserIdAndTargetType(userId, TargetType.AUCTION).size();
        return Map.of("total", total, "artworks", artworks, "auctions", auctions);
    }

    private WatchlistItemDto toDto(WatchlistItem item) {
        WatchlistItemDto dto = new WatchlistItemDto();
        dto.setId(item.getId());
        dto.setUserId(item.getUserId());
        dto.setTargetId(item.getTargetId());
        dto.setTargetType(item.getTargetType());
        dto.setTitle(item.getTitle());
        dto.setAddedAt(item.getAddedAt());
        return dto;
    }
}
