package com.artauction.watchlist.exception;

public class WatchlistItemNotFoundException extends RuntimeException {
    public WatchlistItemNotFoundException(String message) { super(message); }
}
