package com.artauction.watchlist.service;

import com.artauction.watchlist.dto.AddWatchlistRequest;
import com.artauction.watchlist.dto.WatchlistItemDto;
import com.artauction.watchlist.entity.TargetType;
import com.artauction.watchlist.entity.WatchlistItem;
import com.artauction.watchlist.exception.AlreadyWatchedException;
import com.artauction.watchlist.exception.WatchlistItemNotFoundException;
import com.artauction.watchlist.repository.WatchlistRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@SuppressWarnings("null")
@ExtendWith(MockitoExtension.class)
class WatchlistServiceTest {

    @Mock
    private WatchlistRepository watchlistRepository;

    @InjectMocks
    private WatchlistService watchlistService;

    private WatchlistItem sampleItem;
    private static final String USER_ID = "user-123";
    private static final String TARGET_ID = "artwork-456";

    @BeforeEach
    void setUp() {
        sampleItem = new WatchlistItem();
        sampleItem.setId("watch-1");
        sampleItem.setUserId(USER_ID);
        sampleItem.setTargetId(TARGET_ID);
        sampleItem.setTargetType(TargetType.ARTWORK);
        sampleItem.setTitle("Mona Lisa");
    }

    @Test
    void getWatchlistForUser_returnsItems() {
        when(watchlistRepository.findByUserId(USER_ID)).thenReturn(List.of(sampleItem));
        List<WatchlistItemDto> result = watchlistService.getWatchlistForUser(USER_ID);
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getTargetId()).isEqualTo(TARGET_ID);
    }

    @Test
    void addToWatchlist_success() {
        when(watchlistRepository.existsByUserIdAndTargetIdAndTargetType(any(), any(), any())).thenReturn(false);
        when(watchlistRepository.save(any())).thenReturn(sampleItem);

        AddWatchlistRequest req = new AddWatchlistRequest();
        req.setTargetId(TARGET_ID);
        req.setTargetType(TargetType.ARTWORK);
        req.setTitle("Mona Lisa");

        WatchlistItemDto result = watchlistService.addToWatchlist(USER_ID, req);
        assertThat(result.getTargetId()).isEqualTo(TARGET_ID);
    }

    @Test
    void addToWatchlist_duplicate_throwsException() {
        when(watchlistRepository.existsByUserIdAndTargetIdAndTargetType(any(), any(), any())).thenReturn(true);

        AddWatchlistRequest req = new AddWatchlistRequest();
        req.setTargetId(TARGET_ID);
        req.setTargetType(TargetType.ARTWORK);

        assertThatThrownBy(() -> watchlistService.addToWatchlist(USER_ID, req))
                .isInstanceOf(AlreadyWatchedException.class);
    }

    @Test
    void removeFromWatchlist_notFound_throwsException() {
        when(watchlistRepository.existsByUserIdAndTargetIdAndTargetType(any(), any(), any())).thenReturn(false);

        assertThatThrownBy(() -> watchlistService.removeFromWatchlist(USER_ID, TARGET_ID, TargetType.ARTWORK))
                .isInstanceOf(WatchlistItemNotFoundException.class);
    }

    @Test
    void removeFromWatchlist_success() {
        when(watchlistRepository.existsByUserIdAndTargetIdAndTargetType(any(), any(), any())).thenReturn(true);
        doNothing().when(watchlistRepository).deleteByUserIdAndTargetIdAndTargetType(any(), any(), any());

        assertThatCode(() -> watchlistService.removeFromWatchlist(USER_ID, TARGET_ID, TargetType.ARTWORK))
                .doesNotThrowAnyException();
    }

    @Test
    void isWatched_returnsCorrectBoolean() {
        when(watchlistRepository.existsByUserIdAndTargetIdAndTargetType(USER_ID, TARGET_ID, TargetType.ARTWORK))
                .thenReturn(true);
        assertThat(watchlistService.isWatched(USER_ID, TARGET_ID, TargetType.ARTWORK)).isTrue();
    }

    @Test
    void getWatchlistStats_returnsMap() {
        when(watchlistRepository.countByUserId(USER_ID)).thenReturn(3L);
        when(watchlistRepository.findByUserIdAndTargetType(USER_ID, TargetType.ARTWORK))
                .thenReturn(List.of(sampleItem, sampleItem));
        when(watchlistRepository.findByUserIdAndTargetType(USER_ID, TargetType.AUCTION))
                .thenReturn(List.of(sampleItem));

        Map<String, Object> stats = watchlistService.getWatchlistStats(USER_ID);
        assertThat(stats.get("total")).isEqualTo(3L);
        assertThat(stats.get("artworks")).isEqualTo(2L);
        assertThat(stats.get("auctions")).isEqualTo(1L);
    }
}
