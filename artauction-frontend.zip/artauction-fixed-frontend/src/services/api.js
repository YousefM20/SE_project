import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
})

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error)
)

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

// ===================== AUTH API =====================
export const authAPI = {
  // POST /api/auth/login
  // Request: { email, password }
  // Response: { token, userId, email, fullName, role }
  login: (credentials) => api.post('/auth/login', credentials),

  // POST /api/auth/register
  // Request: { fullName, email, password, role, bio }
  // Response: { token, userId, email, fullName, role }
  register: (userData) => api.post('/auth/register', userData),
}

// ===================== USER API =====================
export const userAPI = {
  // GET /api/users/me
  // Response: { id, email, fullName, role, active, approved, bio, createdAt }
  getProfile: () => api.get('/users/me'),

  // PUT /api/users/me
  // Request: { fullName, bio }
  // Response: { id, email, fullName, role, active, approved, bio, createdAt }
  updateProfile: (data) => api.put('/users/me', data),

  // GET /api/users
  getAll: () => api.get('/users'),

  // GET /api/users/{id}
  getById: (id) => api.get(`/users/${id}`),

  // PUT /api/users/{id}/toggle-status
  toggleStatus: (id) => api.put(`/users/${id}/toggle-status`),

  // PUT /api/users/artists/{id}/approve
  approveArtist: (id) => api.put(`/users/artists/${id}/approve`),

  // GET /api/users/artists/pending
  getPendingArtists: () => api.get('/users/artists/pending'),

  // GET /api/users/pending (all pending users)
  getPendingUsers: () => api.get('/users/pending'),

  // DELETE /api/users/{id}
  delete: (id) => api.delete(`/users/${id}`),
}

// ===================== ARTWORK API =====================
export const artworkAPI = {
  // GET /api/artworks
  getAll: () => api.get('/artworks'),

  // GET /api/artworks/{id}
  getById: (id) => api.get(`/artworks/${id}`),

  // POST /api/artworks
  // Request: { title, description, medium, dimensions, yearCreated, startingPrice, imageUrl }
  create: (data) => api.post('/artworks', data),

  // PUT /api/artworks/{id}
  // Request: { title, description, medium, dimensions, yearCreated, startingPrice, imageUrl }
  update: (id, data) => api.put(`/artworks/${id}`, data),

  // DELETE /api/artworks/{id}
  delete: (id) => api.delete(`/artworks/${id}`),

  // GET /api/artworks/search?title={title}
  search: (title) => api.get('/artworks/search', { params: { title } }),

  // GET /api/artworks/artist/{artistId}
  getByArtist: (artistId) => api.get(`/artworks/artist/${artistId}`),
}

// ===================== AUCTION API =====================
export const auctionAPI = {
  // GET /api/auctions
  getAll: (params) => api.get('/auctions', { params }),

  // GET /api/auctions/active
  getActive: () => api.get('/auctions/active'),

  // GET /api/auctions/{id}
  getById: (id) => api.get(`/auctions/${id}`),

  // POST /api/auctions
  // Request: { artworkId, startTime, endTime, reservePrice }
  create: (data) => api.post('/auctions', data),

  // PUT /api/auctions/{id}/cancel
  cancel: (id) => api.put(`/auctions/${id}/cancel`),

  // GET /api/auctions/artist/{artistId}
  getByArtist: (artistId) => api.get(`/auctions/artist/${artistId}`),
}

// ===================== BID API =====================
export const bidAPI = {
  // GET /api/bids/auction/{auctionId}
  getByAuction: (auctionId) => api.get(`/bids/auction/${auctionId}`),

  // POST /api/bids/auction/{auctionId}
  // Request: { amount }
  placeBid: (auctionId, amount) => api.post(`/bids/auction/${auctionId}`, { amount }),

  // GET /api/bids/my-bids
  getMyBids: () => api.get('/bids/my-bids'),
}

// ===================== WATCHLIST API =====================
export const watchlistAPI = {
  // GET /api/watchlist
  getAll: () => api.get('/watchlist'),

  // POST /api/watchlist
  // Request: { targetId, targetType: "ARTWORK" | "AUCTION", title }
  add: (data) => api.post('/watchlist', data),

  // DELETE /api/watchlist?targetId={targetId}&targetType={targetType}
  remove: (targetId, targetType = 'AUCTION') => api.delete('/watchlist', {
    params: { targetId, targetType }
  }),

  // GET /api/watchlist/check?targetId={targetId}&targetType={targetType}
  check: (targetId, targetType = 'AUCTION') => api.get('/watchlist/check', {
    params: { targetId, targetType }
  }),

  // GET /api/watchlist/filter?type={type}
  filterByType: (type) => api.get('/watchlist/filter', { params: { type } }),

  // GET /api/watchlist/stats
  getStats: () => api.get('/watchlist/stats'),
}

// ===================== NOTIFICATION API =====================
export const notificationAPI = {
  // GET /api/notifications/my
  getMy: () => api.get('/notifications/my'),

  // GET /api/notifications/my/unread
  getUnread: () => api.get('/notifications/my/unread'),

  // GET /api/notifications/my/unread-count
  getUnreadCount: () => api.get('/notifications/my/unread-count'),

  // PUT /api/notifications/{id}/read
  markAsRead: (id) => api.put(`/notifications/${id}/read`),

  // PUT /api/notifications/my/read-all
  markAllAsRead: () => api.put('/notifications/my/read-all'),

  // GET /api/notifications/all (admin)
  getAll: () => api.get('/notifications/all'),
}

export default api
