import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import './Auth.css'

const Register = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'BUYER',
    bio: '',
  })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [registered, setRegistered] = useState(false)
  const [registeredName, setRegisteredName] = useState('')
  const { register } = useAuth()

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match')
      return
    }
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters')
      return
    }

    setLoading(true)
    const { confirmPassword, ...registerData } = formData
    const result = await register(registerData)

    if (result.success) {
      setRegisteredName(formData.fullName)
      setRegistered(true)
    } else {
      setError(result.error)
    }
    setLoading(false)
  }

  // ── Pending approval screen ──────────────────────────────────────────────
  if (registered) {
    return (
      <div className="auth-page">
        <div className="auth-container pending-container">
          <div className="pending-icon">⏳</div>
          <h1>Account Created!</h1>
          <p className="pending-headline">Welcome, {registeredName}.</p>
          <p className="pending-body">
            Your account is <strong>pending admin approval</strong>. You'll be able
            to log in as soon as an administrator reviews and approves your registration.
          </p>
          <div className="pending-tip">
            💡 Tip: ask your professor / admin to approve your account at<br />
            <code>/admin</code> → Pending Users tab.
          </div>
          <Link to="/login" className="btn-auth" style={{ marginTop: '1.5rem', display: 'block', textAlign: 'center', textDecoration: 'none' }}>
            Go to Login
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-header">
          <span className="auth-icon">🎨</span>
          <h1>Create Account</h1>
          <p>Join our art community today</p>
        </div>

        <form onSubmit={handleSubmit} className="auth-form">
          {error && <div className="auth-error">{error}</div>}

          <div className="form-group">
            <label htmlFor="fullName">Full Name</label>
            <input type="text" id="fullName" name="fullName" value={formData.fullName}
              onChange={handleChange} placeholder="Your full name" required />
          </div>

          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input type="email" id="email" name="email" value={formData.email}
              onChange={handleChange} placeholder="your@email.com" required autoComplete="email" />
          </div>

          <div className="form-group">
            <label htmlFor="role">I am a</label>
            <select id="role" name="role" value={formData.role} onChange={handleChange} required>
              <option value="BUYER">Bidder / Buyer</option>
              <option value="ARTIST">Artist</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="bio">Bio (optional)</label>
            <textarea id="bio" name="bio" value={formData.bio} onChange={handleChange}
              rows="3" placeholder="Tell us about yourself..." />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input type="password" id="password" name="password" value={formData.password}
              onChange={handleChange} placeholder="Min 6 characters" required autoComplete="new-password" />
          </div>

          <div className="form-group">
            <label htmlFor="confirmPassword">Confirm Password</label>
            <input type="password" id="confirmPassword" name="confirmPassword"
              value={formData.confirmPassword} onChange={handleChange}
              placeholder="Confirm your password" required autoComplete="new-password" />
          </div>

          <button type="submit" className="btn-auth" disabled={loading}>
            {loading ? 'Creating Account...' : 'Create Account'}
          </button>
        </form>

        <div className="auth-footer">
          <p>Already have an account? <Link to="/login">Sign In</Link></p>
        </div>
      </div>
    </div>
  )
}

export default Register
