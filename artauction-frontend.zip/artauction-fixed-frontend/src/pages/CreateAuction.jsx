import React, { useState, useEffect } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { auctionAPI, artworkAPI } from '../services/api.js'
import './CreateAuction.css'

const CreateAuction = () => {
  const navigate = useNavigate()
  const location = useLocation()
  const preselected = location.state?.preselectedArtworkId || ''
  const [artworks, setArtworks] = useState([])
  const [formData, setFormData] = useState({
    artworkId: preselected,
    startTime: '',
    endTime: '',
    reservePrice: '',
  })
  const [loading, setLoading] = useState(false)
  const [fetchLoading, setFetchLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    const fetchArtworks = async () => {
      try {
        const user = JSON.parse(localStorage.getItem('user'))
        const response = user?.id
          ? await artworkAPI.getByArtist(user.id)
          : await artworkAPI.getAll()
        // Only show AVAILABLE artworks (not already in auction)
        const available = (response.data || []).filter(a => a.status === 'AVAILABLE')
        setArtworks(available)
      } catch (err) {
        console.error('Failed to load artworks:', err)
      } finally {
        setFetchLoading(false)
      }
    }
    fetchArtworks()
  }, [])

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const payload = {
        artworkId: formData.artworkId,
        startTime: new Date(formData.startTime).toISOString(),
        endTime: new Date(formData.endTime).toISOString(),
        reservePrice: parseFloat(formData.reservePrice) || 0,
      }

      const response = await auctionAPI.create(payload)
      navigate(`/auctions/${response.data.id}`)
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create auction')
      setLoading(false)
    }
  }

  // Set minimum times
  const now = new Date()
  const minStartTime = new Date(now.getTime() + 60000).toISOString().slice(0, 16)
  const minEndTime = formData.startTime
    ? new Date(new Date(formData.startTime).getTime() + 3600000).toISOString().slice(0, 16)
    : minStartTime

  return (
    <div className="create-auction-page">
      <div className="create-container">
        <h1>Create New Auction</h1>
        <p className="subtitle">Select an artwork and set auction parameters</p>

        {error && <div className="form-error">{error}</div>}

        <form onSubmit={handleSubmit} className="auction-form">
          <div className="form-section">
            <h3>Select Artwork</h3>

            {fetchLoading ? (
              <p>Loading your artworks...</p>
            ) : artworks.length === 0 ? (
              <div className="no-artworks">
                <p>You don't have any artworks yet.</p>
                <button type="button" className="btn-primary" onClick={() => navigate('/artworks/new')}>
                  Create Artwork First
                </button>
              </div>
            ) : (
              <div className="form-group">
                <label htmlFor="artworkId">Artwork *</label>
                <select
                  id="artworkId"
                  name="artworkId"
                  value={formData.artworkId}
                  onChange={handleChange}
                  required
                >
                  <option value="">Select an artwork...</option>
                  {artworks.map(artwork => (
                    <option key={artwork.id} value={artwork.id}>
                      {artwork.title} — {artwork.medium} — ${artwork.startingPrice}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <div className="form-section">
            <h3>Auction Details</h3>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="startTime">Start Time *</label>
                <input
                  type="datetime-local"
                  id="startTime"
                  name="startTime"
                  value={formData.startTime}
                  onChange={handleChange}
                  min={minStartTime}
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="endTime">End Time *</label>
                <input
                  type="datetime-local"
                  id="endTime"
                  name="endTime"
                  value={formData.endTime}
                  onChange={handleChange}
                  min={minEndTime}
                  required
                />
                <small>Auction must run for at least 1 hour</small>
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="reservePrice">Reserve Price ($)</label>
              <input
                type="number"
                id="reservePrice"
                name="reservePrice"
                value={formData.reservePrice}
                onChange={handleChange}
                placeholder="0.00 (optional)"
                min="0"
                step="0.01"
              />
              <small>Minimum price that must be met for the auction to complete</small>
            </div>
          </div>

          <div className="form-actions">
            <button 
              type="button" 
              className="btn-cancel"
              onClick={() => navigate('/auctions')}
            >
              Cancel
            </button>
            <button 
              type="submit" 
              className="btn-submit"
              disabled={loading || !formData.artworkId}
            >
              {loading ? 'Creating...' : 'Create Auction'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default CreateAuction
