import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { userAPI } from '../services/api.js'
import { useAuth } from '../context/AuthContext.jsx'
import './Admin.css'

const ROLE_LABELS = { BUYER: 'Bidder', ARTIST: 'Artist', EMPLOYEE: 'Employee', ADMIN: 'Admin' }
const ROLE_COLORS = { BUYER: '#3b82f6', ARTIST: '#8b5cf6', EMPLOYEE: '#f59e0b', ADMIN: '#ef4444' }

const Admin = () => {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [tab, setTab] = useState('pending')
  const [pendingUsers, setPendingUsers] = useState([])
  const [allUsers, setAllUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState({})
  const [message, setMessage] = useState('')

  // Guard: only ADMIN or EMPLOYEE can view
  useEffect(() => {
    if (user && user.role !== 'ADMIN' && user.role !== 'EMPLOYEE') {
      navigate('/')
    }
  }, [user, navigate])

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    setLoading(true)
    try {
      const [pendingRes, allRes] = await Promise.all([
        userAPI.getPendingUsers(),
        userAPI.getAll(),
      ])
      setPendingUsers(pendingRes.data || [])
      setAllUsers(allRes.data || [])
    } catch (err) {
      setMessage('Failed to load users: ' + (err.response?.data?.message || err.message))
    } finally {
      setLoading(false)
    }
  }

  const handleApprove = async (userId, userName) => {
    setActionLoading(prev => ({ ...prev, [userId]: 'approving' }))
    try {
      await userAPI.approveArtist(userId)
      setMessage(`✅ ${userName} has been approved.`)
      await fetchData()
    } catch (err) {
      setMessage('❌ Failed to approve: ' + (err.response?.data?.message || err.message))
    } finally {
      setActionLoading(prev => ({ ...prev, [userId]: null }))
    }
  }

  const handleToggleStatus = async (userId, userName, currentlyActive) => {
    setActionLoading(prev => ({ ...prev, [userId]: 'toggling' }))
    try {
      await userAPI.toggleStatus(userId)
      setMessage(`✅ ${userName} is now ${currentlyActive ? 'deactivated' : 'activated'}.`)
      await fetchData()
    } catch (err) {
      setMessage('❌ Failed: ' + (err.response?.data?.message || err.message))
    } finally {
      setActionLoading(prev => ({ ...prev, [userId]: null }))
    }
  }

  const approvedUsers = allUsers.filter(u => u.approved)

  return (
    <div className="admin-page">
      <div className="admin-header">
        <h1>🛡️ Admin Dashboard</h1>
        <p>Manage users and system settings</p>
      </div>

      {message && (
        <div className={`admin-flash ${message.startsWith('❌') ? 'error' : 'success'}`}>
          {message}
          <button onClick={() => setMessage('')} className="flash-close">×</button>
        </div>
      )}

      {/* Stats bar */}
      <div className="admin-stats">
        <div className="stat-card">
          <span className="stat-num">{pendingUsers.length}</span>
          <span className="stat-lbl">Pending Approval</span>
        </div>
        <div className="stat-card">
          <span className="stat-num">{approvedUsers.length}</span>
          <span className="stat-lbl">Active Users</span>
        </div>
        <div className="stat-card">
          <span className="stat-num">{allUsers.length}</span>
          <span className="stat-lbl">Total Registered</span>
        </div>
      </div>

      {/* Tab navigation */}
      <div className="admin-tabs">
        <button className={`admin-tab ${tab === 'pending' ? 'active' : ''}`}
          onClick={() => setTab('pending')}>
          Pending Approval {pendingUsers.length > 0 && <span className="badge">{pendingUsers.length}</span>}
        </button>
        <button className={`admin-tab ${tab === 'all' ? 'active' : ''}`}
          onClick={() => setTab('all')}>
          All Users
        </button>
      </div>

      {loading ? (
        <div className="admin-loading">Loading users…</div>
      ) : tab === 'pending' ? (
        <PendingTab users={pendingUsers} actionLoading={actionLoading} onApprove={handleApprove} />
      ) : (
        <AllUsersTab users={allUsers} actionLoading={actionLoading}
          onToggle={handleToggleStatus} onApprove={handleApprove} />
      )}
    </div>
  )
}

const PendingTab = ({ users, actionLoading, onApprove }) => {
  if (users.length === 0) {
    return (
      <div className="admin-empty">
        <span>✅</span>
        <p>No users pending approval.</p>
      </div>
    )
  }

  return (
    <div className="user-table-wrapper">
      <table className="user-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Registered</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {users.map(u => (
            <tr key={u.id}>
              <td className="user-name">{u.fullName}</td>
              <td className="user-email">{u.email}</td>
              <td>
                <span className="role-badge" style={{ background: ROLE_COLORS[u.role] + '22', color: ROLE_COLORS[u.role], border: `1px solid ${ROLE_COLORS[u.role]}` }}>
                  {ROLE_LABELS[u.role] || u.role}
                </span>
              </td>
              <td>{u.createdAt ? new Date(u.createdAt).toLocaleDateString() : '—'}</td>
              <td>
                <button
                  className="btn-approve"
                  disabled={actionLoading[u.id] === 'approving'}
                  onClick={() => onApprove(u.id, u.fullName)}>
                  {actionLoading[u.id] === 'approving' ? 'Approving…' : '✓ Approve'}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

const AllUsersTab = ({ users, actionLoading, onToggle, onApprove }) => (
  <div className="user-table-wrapper">
    <table className="user-table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Role</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {users.map(u => (
          <tr key={u.id} className={!u.active ? 'inactive-row' : ''}>
            <td className="user-name">{u.fullName}</td>
            <td className="user-email">{u.email}</td>
            <td>
              <span className="role-badge" style={{ background: ROLE_COLORS[u.role] + '22', color: ROLE_COLORS[u.role], border: `1px solid ${ROLE_COLORS[u.role]}` }}>
                {ROLE_LABELS[u.role] || u.role}
              </span>
            </td>
            <td>
              <span className={`status-pill ${u.approved ? (u.active ? 'active' : 'inactive') : 'pending'}`}>
                {!u.approved ? '⏳ Pending' : u.active ? '✅ Active' : '🔴 Inactive'}
              </span>
            </td>
            <td className="actions-cell">
              {!u.approved && (
                <button className="btn-approve sm"
                  disabled={actionLoading[u.id] === 'approving'}
                  onClick={() => onApprove(u.id, u.fullName)}>
                  {actionLoading[u.id] === 'approving' ? '…' : 'Approve'}
                </button>
              )}
              {u.approved && (
                <button className={`btn-toggle sm ${u.active ? 'deactivate' : 'activate'}`}
                  disabled={actionLoading[u.id] === 'toggling'}
                  onClick={() => onToggle(u.id, u.fullName, u.active)}>
                  {actionLoading[u.id] === 'toggling' ? '…' : u.active ? 'Deactivate' : 'Activate'}
                </button>
              )}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
)

export default Admin
