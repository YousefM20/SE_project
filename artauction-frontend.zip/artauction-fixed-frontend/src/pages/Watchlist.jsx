import React, { useState, useEffect } from 'react'
import { watchlistAPI, auctionAPI } from '../services/api.js'
import AuctionCard from '../components/auction/AuctionCard.jsx'
import './Watchlist.css'

const Watchlist = () => {
  const [items, setItems] = useState([])
  const [auctions, setAuctions] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const fetchWatchlist = async () => {
    try {
      setLoading(true)
      const response = await watchlistAPI.getAll()
      setItems(response.data)

      // For AUCTION type items, fetch full auction details
      const auctionItems = response.data.filter(item => item.targetType === 'AUCTION')
      if (auctionItems.length > 0) {
        const auctionPromises = auctionItems.map(item => auctionAPI.getById(item.targetId))
        const auctionResponses = await Promise.allSettled(auctionPromises)
        const fetchedAuctions = auctionResponses
          .filter(r => r.status === 'fulfilled')
          .map(r => r.value.data)
        setAuctions(fetchedAuctions)
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load watchlist')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchWatchlist()
  }, [])

  const handleRemove = async (targetId, targetType) => {
    try {
      await watchlistAPI.remove(targetId, targetType)
      setItems(prev => prev.filter(item => !(item.targetId === targetId && item.targetType === targetType)))
      if (targetType === 'AUCTION') {
        setAuctions(prev => prev.filter(a => a.id !== targetId))
      }
    } catch (err) {
      console.error('Failed to remove from watchlist:', err)
    }
  }

  return (
    <div className="watchlist-page">
      <div className="watchlist-header">
        <h1>My Watchlist</h1>
        <p>Track auctions and artworks you're interested in</p>
      </div>

      {loading ? (
        <div className="loading-grid">
          {[1,2,3].map(i => <div key={i} className="skeleton-card" />)}
        </div>
      ) : error ? (
        <div className="error-message">{error}</div>
      ) : items.length === 0 ? (
        <div className="watchlist-empty">
          <span className="empty-icon">🔍</span>
          <h3>Your watchlist is empty</h3>
          <p>Browse auctions and click the star icon to save them here.</p>
        </div>
      ) : (
        <div className="watchlist-grid">
          {auctions.map(auction => (
            <div key={auction.id} className="watchlist-item">
              <AuctionCard auction={auction} />
              <button 
                className="btn-remove"
                onClick={() => handleRemove(auction.id, 'AUCTION')}
                title="Remove from watchlist"
              >
                ✕ Remove
              </button>
            </div>
          ))}
          {items.filter(item => item.targetType === 'ARTWORK').map(item => (
            <div key={item.id} className="watchlist-item artwork-item">
              <div className="watchlist-artwork-card">
                <h3>{item.title}</h3>
                <span className="artwork-type">Artwork</span>
              </div>
              <button 
                className="btn-remove"
                onClick={() => handleRemove(item.targetId, 'ARTWORK')}
                title="Remove from watchlist"
              >
                ✕ Remove
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default Watchlist
