import React, { useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useAuction } from '../hooks/useAuction.js'
import { useAuth } from '../context/AuthContext.jsx'
import { watchlistAPI } from '../services/api.js'
import BidForm from '../components/auction/BidForm.jsx'
import BidHistory from '../components/auction/BidHistory.jsx'
import { formatPrice, formatDate, formatTimeLeft } from '../utils/formatters.js'
import './AuctionDetail.css'

const AuctionDetail = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const { isAuthenticated, user } = useAuth()
  const { auction, loading, error, refresh } = useAuction(id)
  const [inWatchlist, setInWatchlist] = useState(false)
  const [watchlistLoading, setWatchlistLoading] = useState(false)

  const handleWatchlistToggle = async () => {
    if (!isAuthenticated) {
      navigate('/login')
      return
    }
    try {
      setWatchlistLoading(true)
      if (inWatchlist) {
        await watchlistAPI.remove(id, 'AUCTION')
        setInWatchlist(false)
      } else {
        await watchlistAPI.add({
          targetId: id,
          targetType: 'AUCTION',
          title: auction?.title || 'Auction'
        })
        setInWatchlist(true)
      }
    } catch (err) {
      console.error('Watchlist error:', err)
    } finally {
      setWatchlistLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="auction-detail-loading">
        <div className="spinner"></div>
        <p>Loading auction details...</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="auction-detail-error">
        <p>{error}</p>
        <button onClick={() => navigate('/auctions')} className="btn-back">
          ← Back to Auctions
        </button>
      </div>
    )
  }

  if (!auction) return null

  const timeLeft = formatTimeLeft(auction.endTime)

  return (
    <div className="auction-detail-page">
      <button onClick={() => navigate('/auctions')} className="btn-back">
        ← Back to Auctions
      </button>

      <div className="auction-detail-grid">
        <div className="auction-image-section">
          <img 
            src={auction.imageUrl || '/placeholder-art.jpg'} 
            alt={auction.title}
            className="auction-detail-image"
            onError={(e) => {
              e.target.src = 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22600%22 height=%22400%22><rect fill=%22%23f0f0f0%22 width=%22600%22 height=%22400%22/><text fill=%22%23999%22 font-family=%22sans-serif%22 font-size=%2224%22 x=%2250%%22 y=%2250%%22 text-anchor=%22middle%22 dy=%22.3em%22>No Image Available</text></svg>'
            }}
          />
        </div>

        <div className="auction-info-section">
          <div className="auction-header">
            <span className={`status-badge ${auction.status?.toLowerCase()}`}>
              {auction.status}
            </span>
            <button 
              className={`watchlist-btn ${inWatchlist ? 'active' : ''}`}
              onClick={handleWatchlistToggle}
              disabled={watchlistLoading}
            >
              {watchlistLoading ? '...' : inWatchlist ? '★ Saved' : '☆ Watch'}
            </button>
          </div>

          <h1 className="auction-title">{auction.title || auction.artworkTitle}</h1>
          <p className="auction-artist">by {auction.artist || auction.artistName}</p>

          <div className="auction-meta">
            <span className="meta-item">📁 {auction.category || auction.medium}</span>
            <span className="meta-item">📅 Started {formatDate(auction.startTime)}</span>
            <span className="meta-item">🏁 Ends {formatDate(auction.endTime)}</span>
          </div>

          <div className="price-section">
            <div className="price-box">
              <span className="price-label">Current Bid</span>
              <span className="price-value">{formatPrice(auction.currentPrice || auction.startingPrice)}</span>
            </div>
            <div className="price-box">
              <span className="price-label">Starting Price</span>
              <span className="price-value starting">{formatPrice(auction.startingPrice)}</span>
            </div>
          </div>

          <div className={`time-remaining ${timeLeft.urgent ? 'urgent' : ''}`}>
            <span className="time-label">⏰ Time Remaining</span>
            <span className="time-value">{timeLeft.text}</span>
          </div>

          <div className="auction-description">
            <h3>Description</h3>
            <p>{auction.description || 'No description provided.'}</p>
          </div>

          {isAuthenticated && auction.status === 'ACTIVE' && user?.id !== auction.artistId && (
            <BidForm auction={auction} onBidPlaced={refresh} />
          )}

          {isAuthenticated && auction.status === 'ACTIVE' && user?.id === auction.artistId && (
            <div className="owner-notice">
              <p>This is your auction. You cannot bid on your own artwork.</p>
            </div>
          )}

          {!isAuthenticated && auction.status === 'ACTIVE' && (
            <div className="login-to-bid">
              <p>Please <button onClick={() => navigate('/login')} className="link-btn">login</button> to place a bid</p>
            </div>
          )}
        </div>
      </div>

      <div className="auction-bids-section">
        <BidHistory bids={auction.bids || []} />
      </div>
    </div>
  )
}

export default AuctionDetail
