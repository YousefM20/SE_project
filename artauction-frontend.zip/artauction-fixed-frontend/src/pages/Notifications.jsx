import React from 'react'
import { useNotifications } from '../context/NotificationContext.jsx'
import { formatDate } from '../utils/formatters.js'
import './Notifications.css'

const Notifications = () => {
  const { notifications, unreadCount, markAsRead, markAllAsRead } = useNotifications()

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'BID_PLACED': return '💰'
      case 'OUTBID': return '📉'
      case 'AUCTION_WON': return '🏆'
      case 'AUCTION_ENDED': return '⏰'
      case 'AUCTION_CREATED': return '🎨'
      default: return '🔔'
    }
  }

  return (
    <div className="notifications-page">
      <div className="notifications-header">
        <h1>Notifications</h1>
        {unreadCount > 0 && (
          <button className="btn-mark-all" onClick={markAllAsRead}>
            Mark all as read ({unreadCount})
          </button>
        )}
      </div>

      {notifications.length === 0 ? (
        <div className="notifications-empty">
          <span className="empty-icon">🔔</span>
          <h3>No notifications yet</h3>
          <p>We'll notify you about important auction events here.</p>
        </div>
      ) : (
        <div className="notifications-list">
          {notifications.map(notification => (
            <div 
              key={notification.id} 
              className={`notification-item ${!notification.read ? 'unread' : ''}`}
              onClick={() => !notification.read && markAsRead(notification.id)}
            >
              <div className="notification-icon">
                {getNotificationIcon(notification.type)}
              </div>
              <div className="notification-content">
                <p className="notification-message">{notification.message}</p>
                <span className="notification-time">
                  {formatDate(notification.createdAt)}
                </span>
              </div>
              {!notification.read && <div className="unread-dot" />}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default Notifications
