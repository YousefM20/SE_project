import React from 'react'
import { Link } from 'react-router-dom'
import { useAuctions } from '../hooks/useAuctions.js'
import AuctionCard from '../components/auction/AuctionCard.jsx'
import './Home.css'

const Home = () => {
  const { auctions, loading, error } = useAuctions({ status: 'ACTIVE' })

  return (
    <div className="home-page">
      {/* Hero Section */}
      <section className="hero">
        <div className="hero-content">
          <h1>Discover & Collect Fine Art</h1>
          <p>Bid on exclusive artworks from talented artists around the world</p>
          <div className="hero-buttons">
            <Link to="/auctions" className="btn-primary">Browse Auctions</Link>
            <Link to="/create-auction" className="btn-secondary">Sell Artwork</Link>
          </div>
        </div>
        <div className="hero-stats">
          <div className="stat">
            <span className="stat-number">500+</span>
            <span className="stat-label">Artworks</span>
          </div>
          <div className="stat">
            <span className="stat-number">200+</span>
            <span className="stat-label">Artists</span>
          </div>
          <div className="stat">
            <span className="stat-number">10K+</span>
            <span className="stat-label">Bidders</span>
          </div>
        </div>
      </section>

      {/* Featured Auctions */}
      <section className="featured-section">
        <div className="section-header">
          <h2>Featured Auctions</h2>
          <Link to="/auctions" className="view-all">View All →</Link>
        </div>

        {loading ? (
          <div className="loading-grid">
            {[1,2,3].map(i => <div key={i} className="skeleton-card" />)}
          </div>
        ) : error ? (
          <div className="error-message">{error}</div>
        ) : (
          <div className="auctions-grid">
            {auctions.slice(0, 6).map(auction => (
              <AuctionCard key={auction.id} auction={auction} />
            ))}
          </div>
        )}
      </section>

      {/* How It Works */}
      <section className="how-it-works">
        <h2>How It Works</h2>
        <div className="steps">
          <div className="step">
            <div className="step-icon">🔍</div>
            <h3>Discover</h3>
            <p>Browse unique artworks from verified artists</p>
          </div>
          <div className="step">
            <div className="step-icon">💰</div>
            <h3>Bid</h3>
            <p>Place competitive bids in real-time auctions</p>
          </div>
          <div className="step">
            <div className="step-icon">🏆</div>
            <h3>Win</h3>
            <p>Secure the artwork and complete payment</p>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Home
