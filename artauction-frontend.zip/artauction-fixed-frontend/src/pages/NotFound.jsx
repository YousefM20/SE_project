import React from 'react'
import { Link } from 'react-router-dom'
import './NotFound.css'

const NotFound = () => {
  return (
    <div className="not-found-page">
      <div className="not-found-content">
        <span className="not-found-icon">🎨</span>
        <h1>404</h1>
        <h2>Artwork Not Found</h2>
        <p>The page you're looking for seems to have been auctioned off.</p>
        <Link to="/" className="btn-home">
          ← Back to Gallery
        </Link>
      </div>
    </div>
  )
}

export default NotFound
