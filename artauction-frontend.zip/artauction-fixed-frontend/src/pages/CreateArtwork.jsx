import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { artworkAPI } from '../services/api.js'
import './CreateAuction.css'

const CreateArtwork = () => {
  const navigate = useNavigate()
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    medium: '',
    dimensions: '',
    yearCreated: '',
    startingPrice: '',
    imageUrl: '',
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const payload = {
        title: formData.title,
        description: formData.description,
        medium: formData.medium,
        dimensions: formData.dimensions,
        yearCreated: formData.yearCreated ? parseInt(formData.yearCreated) : null,
        startingPrice: parseFloat(formData.startingPrice),
        imageUrl: formData.imageUrl || null,
      }

      await artworkAPI.create(payload)
      // After creating, redirect to create auction so they can put it up immediately
      navigate('/create-auction')
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create artwork')
      setLoading(false)
    }
  }

  return (
    <div className="create-auction-page">
      <div className="create-container">
        <h1>Upload New Artwork</h1>
        <p className="subtitle">Add your artwork to the catalogue before creating an auction</p>

        {error && <div className="form-error">{error}</div>}

        <form onSubmit={handleSubmit} className="auction-form">
          <div className="form-section">
            <h3>Artwork Details</h3>

            <div className="form-group">
              <label htmlFor="title">Title *</label>
              <input
                type="text"
                id="title"
                name="title"
                value={formData.title}
                onChange={handleChange}
                placeholder="e.g. Sunrise Over Cairo"
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="description">Description</label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                placeholder="Describe your artwork..."
                rows={4}
                style={{ resize: 'vertical', padding: '0.6rem', borderRadius: '6px', border: '1px solid var(--gray-300)', fontSize: '1rem' }}
              />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="medium">Medium *</label>
                <input
                  type="text"
                  id="medium"
                  name="medium"
                  value={formData.medium}
                  onChange={handleChange}
                  placeholder="e.g. Oil on Canvas"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="dimensions">Dimensions</label>
                <input
                  type="text"
                  id="dimensions"
                  name="dimensions"
                  value={formData.dimensions}
                  onChange={handleChange}
                  placeholder="e.g. 80x60cm"
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="yearCreated">Year Created</label>
                <input
                  type="number"
                  id="yearCreated"
                  name="yearCreated"
                  value={formData.yearCreated}
                  onChange={handleChange}
                  placeholder="e.g. 2024"
                  min="1000"
                  max={new Date().getFullYear()}
                />
              </div>

              <div className="form-group">
                <label htmlFor="startingPrice">Starting Price ($) *</label>
                <input
                  type="number"
                  id="startingPrice"
                  name="startingPrice"
                  value={formData.startingPrice}
                  onChange={handleChange}
                  placeholder="e.g. 500.00"
                  min="0.01"
                  step="0.01"
                  required
                />
                <small>Minimum starting bid for this artwork</small>
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="imageUrl">Image URL</label>
              <input
                type="url"
                id="imageUrl"
                name="imageUrl"
                value={formData.imageUrl}
                onChange={handleChange}
                placeholder="https://example.com/my-artwork.jpg"
              />
              <small>Paste a link to an image of your artwork (optional)</small>
            </div>
          </div>

          <div className="form-actions">
            <button
              type="button"
              className="btn-cancel"
              onClick={() => navigate('/create-auction')}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn-submit"
              disabled={loading}
            >
              {loading ? 'Uploading...' : 'Upload Artwork'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default CreateArtwork
