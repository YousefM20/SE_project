import React, { useState } from 'react'
import { useAuctions } from '../hooks/useAuctions.js'
import AuctionCard from '../components/auction/AuctionCard.jsx'
import './Auctions.css'

const Auctions = () => {
  const [filters, setFilters] = useState({
    status: 'ACTIVE',
    search: '',
  })

  const { auctions, loading, error, refresh } = useAuctions(filters)
  const [searchInput, setSearchInput] = useState('')

  const handleSearch = (e) => {
    e.preventDefault()
    setFilters(prev => ({ ...prev, search: searchInput }))
  }

  return (
    <div className="auctions-page">
      <div className="auctions-header">
        <h1>Browse Auctions</h1>

        <form onSubmit={handleSearch} className="search-form">
          <input
            type="text"
            placeholder="Search artworks, artists..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="search-input"
          />
          <button type="submit" className="btn-search">🔍</button>
        </form>
      </div>

      <div className="filters">
        <div className="status-filters">
          <button 
            className={`filter-btn ${filters.status === 'ACTIVE' ? 'active' : ''}`}
            onClick={() => setFilters(prev => ({ ...prev, status: 'ACTIVE' }))}
          >
            Active
          </button>
          <button 
            className={`filter-btn ${filters.status === 'ENDED' ? 'active' : ''}`}
            onClick={() => setFilters(prev => ({ ...prev, status: 'ENDED' }))}
          >
            Ended
          </button>
          <button 
            className={`filter-btn ${filters.status === '' ? 'active' : ''}`}
            onClick={() => setFilters(prev => ({ ...prev, status: '' }))}
          >
            All
          </button>
        </div>
      </div>

      {loading ? (
        <div className="loading-grid">
          {[1,2,3,4,5,6].map(i => <div key={i} className="skeleton-card" />)}
        </div>
      ) : error ? (
        <div className="error-message">{error}</div>
      ) : auctions.length === 0 ? (
        <div className="no-results">
          <p>No auctions found matching your criteria.</p>
        </div>
      ) : (
        <div className="auctions-grid">
          {auctions.map(auction => (
            <AuctionCard key={auction.id} auction={auction} />
          ))}
        </div>
      )}
    </div>
  )
}

export default Auctions
