import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { userAPI, artworkAPI } from '../services/api.js'
import { useAuth } from '../context/AuthContext.jsx'
import './Profile.css'

const STATUS_COLOR = {
  AVAILABLE:  { bg: '#ecfdf5', color: '#065f46', label: 'Available' },
  IN_AUCTION: { bg: '#eff6ff', color: '#1d4ed8', label: 'In Auction' },
  SOLD:       { bg: '#fef2f2', color: '#991b1b', label: 'Sold' },
}

const Profile = () => {
  const { user, updateUser } = useAuth()
  const navigate = useNavigate()
  const [profileData, setProfileData] = useState(null)
  const [artworks, setArtworks] = useState([])
  const [isEditing, setIsEditing] = useState(false)
  const [formData, setFormData] = useState({ fullName: '', bio: '' })
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const res = await userAPI.getProfile()
        setProfileData(res.data)
        setFormData({ fullName: res.data.fullName || '', bio: res.data.bio || '' })

        // If artist, load their artworks
        if (res.data.role === 'ARTIST' || user?.role === 'ARTIST') {
          try {
            const aRes = await artworkAPI.getByArtist(res.data.id)
            setArtworks(aRes.data || [])
          } catch { setArtworks([]) }
        }
      } catch (err) {
        console.error('Failed to load profile:', err)
      }
    }
    fetchAll()
  }, [user?.role])

  const handleChange = (e) =>
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }))

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setMessage('')
    try {
      const res = await userAPI.updateProfile(formData)
      setProfileData(res.data)
      updateUser({ ...user, fullName: res.data.fullName })
      setMessage('Profile updated successfully!')
      setIsEditing(false)
    } catch (err) {
      setMessage(err.response?.data?.message || 'Failed to update profile')
    } finally { setLoading(false) }
  }

  const displayUser = profileData || user
  const initials = displayUser?.fullName
    ? displayUser.fullName.split(' ').map(n => n[0]).join('').toUpperCase()
    : '??'

  const isArtist = displayUser?.role === 'ARTIST'

  return (
    <div className="profile-page">
      <div className="profile-container">

        {/* ── Header ─────────────────────────────────────── */}
        <div className="profile-header">
          <div className="profile-avatar">{initials}</div>
          <div className="profile-info">
            <h1>{displayUser?.fullName || 'User'}</h1>
            <p className="profile-email">{displayUser?.email}</p>
            <p className="profile-role">{displayUser?.role}</p>
          </div>
        </div>

        {message && (
          <div className={`profile-message ${message.includes('success') ? 'success' : 'error'}`}>
            {message}
          </div>
        )}

        {/* ── Profile Details ─────────────────────────────── */}
        <div className="profile-section">
          <div className="section-header">
            <h2>Profile Information</h2>
            <button className="btn-edit" onClick={() => setIsEditing(!isEditing)}>
              {isEditing ? 'Cancel' : 'Edit Profile'}
            </button>
          </div>

          {isEditing ? (
            <form onSubmit={handleSubmit} className="profile-form">
              <div className="form-group">
                <label>Full Name</label>
                <input type="text" name="fullName" value={formData.fullName}
                  onChange={handleChange} required />
              </div>
              <div className="form-group">
                <label>Bio</label>
                <textarea name="bio" value={formData.bio} onChange={handleChange}
                  rows="4" placeholder="Tell us about yourself..." />
              </div>
              <button type="submit" className="btn-save" disabled={loading}>
                {loading ? 'Saving...' : 'Save Changes'}
              </button>
            </form>
          ) : (
            <div className="profile-details">
              {[
                ['Full Name', displayUser?.fullName],
                ['Email', displayUser?.email],
                ['Role', displayUser?.role],
                ['Status', displayUser?.active
                  ? (displayUser?.approved ? 'Active ✅' : 'Pending Approval ⏳')
                  : 'Inactive 🔴'],
                ['Bio', displayUser?.bio || 'No bio added yet.'],
                ['Member Since', displayUser?.createdAt
                  ? new Date(displayUser.createdAt).toLocaleDateString() : 'N/A'],
              ].map(([label, value]) => (
                <div className="detail-item" key={label}>
                  <span className="detail-label">{label}</span>
                  <span className="detail-value">{value}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ── Artist: My Artworks ─────────────────────────── */}
        {isArtist && (
          <div className="profile-section">
            <div className="section-header">
              <h2>My Artworks</h2>
              <button className="btn-edit" onClick={() => navigate('/artworks/new')}>
                + Upload Artwork
              </button>
            </div>

            {artworks.length === 0 ? (
              <div className="artworks-empty">
                <p>You haven't uploaded any artworks yet.</p>
                <button className="btn-save" onClick={() => navigate('/artworks/new')}
                  style={{ marginTop: '0.75rem' }}>
                  Upload Your First Artwork
                </button>
              </div>
            ) : (
              <div className="artworks-grid">
                {artworks.map(artwork => {
                  const s = STATUS_COLOR[artwork.status] || STATUS_COLOR.AVAILABLE
                  return (
                    <div className="artwork-card" key={artwork.id}>
                      {artwork.imageUrl ? (
                        <img src={artwork.imageUrl} alt={artwork.title}
                          className="artwork-thumb"
                          onError={e => { e.target.style.display='none' }} />
                      ) : (
                        <div className="artwork-thumb placeholder-thumb">🖼️</div>
                      )}
                      <div className="artwork-card-body">
                        <h4>{artwork.title}</h4>
                        <p className="artwork-meta">{artwork.medium} · ${artwork.startingPrice}</p>
                        <span className="artwork-status"
                          style={{ background: s.bg, color: s.color }}>
                          {s.label}
                        </span>
                      </div>
                      <div className="artwork-card-actions">
                        {artwork.status === 'AVAILABLE' ? (
                          <button
                            className="btn-start-auction"
                            onClick={() => navigate('/create-auction', {
                              state: { preselectedArtworkId: artwork.id }
                            })}>
                            🔨 Start Auction
                          </button>
                        ) : (
                          <span className="artwork-action-info">
                            {artwork.status === 'IN_AUCTION' ? 'Currently in auction' : 'Sold'}
                          </span>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

export default Profile
