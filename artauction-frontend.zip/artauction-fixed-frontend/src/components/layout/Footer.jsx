import React from 'react'
import './Footer.css'

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-brand">
          <span className="footer-logo">🎨 Art Auction</span>
          <p className="footer-tagline">Fine Art Auctions</p>
        </div>
        <div className="footer-links">
          <a href="/auctions">Browse Auctions</a>
          <a href="/create-auction">Sell Artwork</a>
          <a href="/">How It Works</a>
        </div>
        <div className="footer-bottom">
          <p>© 2026 Art Auction. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

export default Footer
