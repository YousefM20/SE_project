import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext.jsx'
import { useNotifications } from '../../context/NotificationContext.jsx'
import './Navbar.css'

const Navbar = () => {
  const { isAuthenticated, user, logout } = useAuth()
  const { unreadCount } = useNotifications()
  const navigate = useNavigate()
  const [menuOpen, setMenuOpen] = useState(false)

  const handleLogout = () => {
    logout()
    navigate('/')
    setMenuOpen(false)
  }

  const isAdmin = user?.role === 'ADMIN' || user?.role === 'EMPLOYEE'
  const isArtist = user?.role === 'ARTIST'

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-logo">
          <span className="logo-icon">🎨</span>
          <span className="logo-text">Art Auction</span>
        </Link>

        <div className={`navbar-menu ${menuOpen ? 'active' : ''}`}>
          <Link to="/auctions" className="nav-link" onClick={() => setMenuOpen(false)}>
            Auctions
          </Link>

          {isAuthenticated ? (
            <>
              <Link to="/watchlist" className="nav-link" onClick={() => setMenuOpen(false)}>
                Watchlist
              </Link>
              <Link to="/notifications" className="nav-link notification-link" onClick={() => setMenuOpen(false)}>
                Notifications
                {unreadCount > 0 && <span className="notification-badge">{unreadCount}</span>}
              </Link>

              {isArtist && (
                <Link to="/create-auction" className="nav-link btn-create" onClick={() => setMenuOpen(false)}>
                  + Sell Art
                </Link>
              )}

              {isAdmin && (
                <Link to="/admin" className="nav-link btn-admin" onClick={() => setMenuOpen(false)}>
                  🛡️ Admin
                </Link>
              )}

              <div className="nav-user-menu">
                <span className="nav-username">{user?.fullName || 'User'}</span>
                <div className="dropdown">
                  <Link to="/profile" className="dropdown-item" onClick={() => setMenuOpen(false)}>
                    Profile
                  </Link>
                  <button className="dropdown-item logout-btn" onClick={handleLogout}>
                    Logout
                  </button>
                </div>
              </div>
            </>
          ) : (
            <>
              <Link to="/login" className="nav-link btn-login" onClick={() => setMenuOpen(false)}>
                Login
              </Link>
              <Link to="/register" className="nav-link btn-register" onClick={() => setMenuOpen(false)}>
                Register
              </Link>
            </>
          )}
        </div>

        <button className="navbar-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">
          <span></span><span></span><span></span>
        </button>
      </div>
    </nav>
  )
}

export default Navbar
