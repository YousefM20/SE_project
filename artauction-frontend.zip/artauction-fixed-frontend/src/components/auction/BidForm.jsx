import React, { useState } from 'react'
import { bidAPI } from '../../services/api.js'
import { formatPrice } from '../../utils/formatters.js'
import './BidForm.css'

const BidForm = ({ auction, onBidPlaced }) => {
  const [amount, setAmount] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  // Minimum bid = currentPrice + smallest valid increment (backend enforces > currentPrice)
  const currentPrice = parseFloat(auction.currentPrice || auction.startingPrice || 0)
  const minBid = parseFloat((currentPrice + 0.01).toFixed(2))

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setSuccess('')

    const bidAmount = parseFloat(amount)
    if (isNaN(bidAmount) || bidAmount < minBid) {
      setError(`Minimum bid is ${formatPrice(minBid)}`)
      return
    }

    try {
      setLoading(true)
      await bidAPI.placeBid(auction.id, bidAmount)
      setSuccess('Bid placed successfully!')
      setAmount('')
      onBidPlaced?.()
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to place bid')
    } finally {
      setLoading(false)
    }
  }

  if (auction.status !== 'ACTIVE') {
    return (
      <div className="bid-form-closed">
        <p>This auction is {auction.status?.toLowerCase()}.</p>
      </div>
    )
  }

  return (
    <div className="bid-form-container">
      <h3>Place a Bid</h3>
      <p className="min-bid-info">Minimum bid: {formatPrice(minBid)}</p>

      <form onSubmit={handleSubmit} className="bid-form">
        <div className="bid-input-group">
          <span className="currency">$</span>
          <input
            type="number"
            step="0.01"
            min={minBid}
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder={`Enter amount (min ${minBid})`}
            className="bid-input"
            required
          />
        </div>

        {error && <div className="bid-error">{error}</div>}
        {success && <div className="bid-success">{success}</div>}

        <button 
          type="submit" 
          className="btn-bid"
          disabled={loading}
        >
          {loading ? 'Placing Bid...' : 'Place Bid'}
        </button>
      </form>
    </div>
  )
}

export default BidForm
