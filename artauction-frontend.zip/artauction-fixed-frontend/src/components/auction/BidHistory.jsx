import React from 'react'
import { formatPrice, formatDate } from '../../utils/formatters.js'
import './BidHistory.css'

const BidHistory = ({ bids }) => {
  if (!bids || bids.length === 0) {
    return (
      <div className="bid-history-empty">
        <p>No bids yet. Be the first to bid!</p>
      </div>
    )
  }

  // Sort by amount descending (highest first)
  const sortedBids = [...bids].sort((a, b) => (b.amount || 0) - (a.amount || 0))

  return (
    <div className="bid-history">
      <h3>Bid History</h3>
      <div className="bid-list">
        {sortedBids.map((bid, index) => (
          <div key={bid.id || index} className={`bid-item ${index === 0 ? 'highest' : ''}`}>
            <div className="bid-rank">#{index + 1}</div>
            <div className="bid-info">
              <span className="bidder">{bid.bidderName || 'Anonymous'}</span>
              <span className="bid-time">{formatDate(bid.placedAt || bid.createdAt)}</span>
            </div>
            <div className="bid-amount">{formatPrice(bid.amount)}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default BidHistory
