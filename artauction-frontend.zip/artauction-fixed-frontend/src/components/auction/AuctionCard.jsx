import React from 'react'
import { Link } from 'react-router-dom'
import { formatPrice, formatTimeLeft, getStatusColor } from '../../utils/formatters.js'
import './AuctionCard.css'

const AuctionCard = ({ auction }) => {
  const timeLeft = formatTimeLeft(auction.endTime)
  const statusColor = getStatusColor(auction.status)

  return (
    <div className="auction-card">
      <div className="auction-image-container">
        <img 
          src={auction.imageUrl || '/placeholder-art.jpg'} 
          alt={auction.title || auction.artworkTitle}
          className="auction-image"
          onError={(e) => {
            e.target.src = 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22300%22><rect fill=%22%23f0f0f0%22 width=%22400%22 height=%22300%22/><text fill=%22%23999%22 font-family=%22sans-serif%22 font-size=%2220%22 x=%2250%%22 y=%2250%%22 text-anchor=%22middle%22 dy=%22.3em%22>No Image</text></svg>'
          }}
        />
        <span className={`auction-status ${statusColor}`}>{auction.status}</span>
      </div>

      <div className="auction-content">
        <h3 className="auction-title">{auction.title || auction.artworkTitle}</h3>
        <p className="auction-artist">by {auction.artist || auction.artistName || 'Unknown'}</p>

        <div className="auction-details">
          <div className="auction-price">
            <span className="price-label">Current Bid</span>
            <span className="price-value">{formatPrice(auction.currentPrice || auction.startingPrice)}</span>
          </div>

          <div className="auction-time">
            <span className="time-label">Ends in</span>
            <span className={`time-value ${timeLeft.urgent ? 'urgent' : ''}`}>
              {timeLeft.text}
            </span>
          </div>
        </div>

        <div className="auction-meta">
          <span className="auction-category">{auction.category || auction.medium || 'Art'}</span>
          <span className="auction-bids">{auction.totalBids || auction.bidCount || 0} bids</span>
        </div>

        <Link to={`/auctions/${auction.id}`} className="btn-view">
          View Auction →
        </Link>
      </div>
    </div>
  )
}

export default AuctionCard
