import { useState, useEffect, useCallback } from 'react'
import { auctionAPI, artworkAPI } from '../services/api.js'

export const useAuctions = (filters = {}) => {
  const [auctions, setAuctions] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const fetchAuctions = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      let response
      if (filters.status === 'ACTIVE') {
        response = await auctionAPI.getActive()
      } else {
        response = await auctionAPI.getAll(filters)
      }
      // Backend returns array directly (not paginated in the spec shown)
      const data = Array.isArray(response.data) ? response.data : (response.data.content || [])
      setAuctions(data)
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load auctions')
    } finally {
      setLoading(false)
    }
  }, [filters.status])

  useEffect(() => {
    fetchAuctions()
  }, [fetchAuctions])

  return { auctions, loading, error, refresh: fetchAuctions }
}

export const useArtworks = () => {
  const [artworks, setArtworks] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const fetchArtworks = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      const response = await artworkAPI.getAll()
      setArtworks(response.data)
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load artworks')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchArtworks()
  }, [fetchArtworks])

  return { artworks, loading, error, refresh: fetchArtworks }
}
