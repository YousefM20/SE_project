import { useState, useEffect } from 'react'
import { auctionAPI, artworkAPI, bidAPI } from '../services/api.js'

export const useAuction = (id) => {
  const [auction, setAuction] = useState(null)
  const [artwork, setArtwork] = useState(null)
  const [bids, setBids] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchAuction = async () => {
      if (!id) {
        setLoading(false)
        return
      }
      try {
        setLoading(true)
        // Fetch auction details
        const auctionRes = await auctionAPI.getById(id)
        const auctionData = auctionRes.data
        setAuction(auctionData)

        // Fetch artwork details separately
        if (auctionData.artworkId) {
          try {
            const artworkRes = await artworkAPI.getById(auctionData.artworkId)
            setArtwork(artworkRes.data)
          } catch {
            setArtwork(null)
          }
        }

        // Fetch bids separately
        try {
          const bidsRes = await bidAPI.getByAuction(id)
          setBids(bidsRes.data)
        } catch {
          setBids([])
        }
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to load auction')
      } finally {
        setLoading(false)
      }
    }

    fetchAuction()
  }, [id])

  const refresh = async () => {
    if (!id) return
    try {
      const auctionRes = await auctionAPI.getById(id)
      setAuction(auctionRes.data)
      const bidsRes = await bidAPI.getByAuction(id)
      setBids(bidsRes.data)
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to refresh auction')
    }
  }

  // Combine auction + artwork data for UI consumption
  const combinedAuction = auction ? {
    ...auction,
    title: artwork?.title || auction.artworkTitle,
    artist: artwork?.artistName || auction.artistName || 'Unknown Artist',
    description: artwork?.description || auction.description || '',
    imageUrl: artwork?.imageUrl || auction.imageUrl || '',
    category: artwork?.medium || auction.medium || '',
    startingPrice: artwork?.startingPrice || auction.startingPrice,
    bids: bids,
    bidCount: bids.length,
  } : null

  return { auction: combinedAuction, loading, error, refresh }
}
