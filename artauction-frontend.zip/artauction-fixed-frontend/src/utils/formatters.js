export const formatPrice = (price) => {
  if (price === undefined || price === null) return '$0.00'
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(price)
}

export const formatDate = (dateString) => {
  if (!dateString) return 'N/A'
  const date = new Date(dateString)
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date)
}

export const formatTimeLeft = (endTime) => {
  if (!endTime) return { text: 'N/A', urgent: false }

  const end = new Date(endTime).getTime()
  const now = Date.now()
  const diff = end - now

  if (diff <= 0) {
    return { text: 'Ended', urgent: true }
  }

  const days = Math.floor(diff / (1000 * 60 * 60 * 24))
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))

  let text = ''
  if (days > 0) {
    text = `${days}d ${hours}h`
  } else if (hours > 0) {
    text = `${hours}h ${minutes}m`
  } else {
    text = `${minutes}m`
  }

  return {
    text,
    urgent: diff < 3600000, // less than 1 hour
  }
}

export const getStatusColor = (status) => {
  switch (status?.toUpperCase()) {
    case 'ACTIVE': return 'status-active'
    case 'ENDED': return 'status-ended'
    case 'CANCELLED': return 'status-cancelled'
    case 'SOLD': return 'status-sold'
    default: return 'status-default'
  }
}
